"""One purchase using the game's saved auto-buy settings."""
import time
from datetime import datetime
from pathlib import Path
import numpy as np
from window_link import capture
from game_actions import check_game_view, click_client_point
from vision import from_capture, shop, purchase_dialog, notice, no_buy_items


def wallet(image):
    return np.asarray(image.convert('L'), dtype=np.float64)[7:26, 420:510].copy()


def wallet_similarity(before, after):
    a, b = before.ravel(), after.ravel()
    a, b = a-a.mean(), b-b.mean()
    denominator = np.linalg.norm(a)*np.linalg.norm(b)
    return float(np.dot(a, b)/denominator) if denominator > 1 else 1.0


class BuyRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self, reason='정지 버튼 또는 다른 작업 시작으로 중지'):
        was_active = self.active
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None
        if was_active and reason:
            self.log(reason)

    def log(self, text):
        self.owner.town_log('[자동 구매] ' + text)
        try:
            directory = Path(__file__).resolve().parent/'diagnostics'
            directory.mkdir(exist_ok=True)
            with (directory/'auto_buy_trace.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} [{getattr(self, "phase", "idle")}] {text}\n')
        except OSError:
            pass

    def schedule(self):
        self.job = self.owner.after(700, self.tick)

    def start(self, handle=None, chained=False):
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = handle or self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        self.phase = 'inspect'
        self.hits = 0
        self.evidence = None
        self.probed = set()
        self.last_scores = None
        self.no_items_hits = 0
        self.no_purchase = False
        self.active = True
        self.limit = time.monotonic()+20
        self.countdown(3)

    def countdown(self, seconds):
        self.job = None
        if not self.active:
            return
        if seconds:
            self.log(f'{seconds}초 후 시작 · 주모 상점 또는 구매 확인창이 열린 게임을 활성화하세요.')
            self.job = self.owner.after(1000, lambda: self.countdown(seconds-1))
        else:
            self.tick()

    def save(self, image, label):
        try:
            directory = Path(__file__).resolve().parent/'diagnostics'
            directory.mkdir(exist_ok=True)
            image.save(directory/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_buy_{label}.png')
        except OSError:
            pass

    def advance(self, phase, timeout):
        self.phase = phase
        self.hits = 0
        self.limit = time.monotonic()+timeout

    def confirm(self, image):
        self.before = wallet(image)
        self.save(image, 'before_confirm')
        detail = click_client_point(self.handle, .622, .643)
        self.confirmed_at = time.monotonic()
        self.log(f'구매 문구·비용 항목·주모 상점 연속 확인 → 확인 1회 · {detail}')
        self.advance('result', 14)

    def finish(self, text, image=None, success=False):
        if self.owner.supply_runner.active and not success:
            self.owner.supply_runner.fail(text, image)
        self.stop(reason=None)
        if image is not None:
            self.save(image, self.phase)
        self.log(text)

    def tick(self):
        self.job = None
        if not self.active:
            return
        image = None
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결 창이 바뀌어 중지했습니다.')
            check_game_view(self.handle)
            image = from_capture(capture(self.handle))
            if time.monotonic() > self.limit:
                raise RuntimeError(f'{self.phase} 확인 시간 초과 · 구매 요청을 반복하지 않습니다.')
            merchant = shop(image)
            title, cost = purchase_dialog(image)
            dialog = title >= .88 and cost >= .80
            alert = notice(image) >= .82
            scores = (self.phase, round(title, 2), round(cost, 2), round(merchant, 2), alert)
            if scores != self.last_scores:
                self.log(f'화면 점수 · 구매제목 {title:.3f} / 비용 {cost:.3f} / 상점 {merchant:.3f} / 알림 {alert} · 연속 {self.hits}/2')
                self.last_scores = scores
            if self.phase not in self.probed:
                self.save(image, self.phase+'_probe')
                self.probed.add(self.phase)
            if alert:
                known = merchant >= .88 and not dialog and no_buy_items(image) >= .90
                if not known or self.phase not in ('inspect', 'dialog', 'result', 'clear_notice'):
                    raise RuntimeError('확인되지 않은 알림창이 나타나 중지했습니다. 구매를 반복하지 않습니다.')
                self.hits = 0
                if self.phase != 'clear_notice':
                    self.no_items_hits += 1
                    if self.no_items_hits >= 2:
                        self.save(image, 'no_items')
                        click_client_point(self.handle, .5, 381/600)
                        self.no_purchase = True
                        self.log('주모 상점·구매할 수 있는 아이템이 없습니다 문구 연속 확인 → 알림 확인 1회 · 추가 구매 없이 다음 단계 준비')
                        self.advance('clear_notice', 8)
                self.schedule()
                return
            self.no_items_hits = 0
            if self.phase == 'inspect':
                evidence = 'dialog' if dialog and merchant >= .88 else 'shop' if merchant >= .90 and not dialog else None
                if evidence != self.evidence:
                    self.hits = 0
                    self.evidence = evidence
                if dialog and merchant >= .88:
                    self.hits += 1
                    if self.hits >= 2:
                        self.confirm(image)
                elif merchant >= .90 and not dialog:
                    self.hits += 1
                    if self.hits >= 2:
                        click_client_point(self.handle, .135, .972)
                        self.log('주모 상점 연속 확인 → 자동 구매 1회 클릭 → 확인창 대기')
                        self.advance('dialog', 10)
                else:
                    self.hits = 0
            elif self.phase == 'dialog':
                self.hits = self.hits+1 if dialog and merchant >= .88 else 0
                if self.hits >= 2:
                    self.confirm(image)
            elif self.phase == 'result':
                correlation = wallet_similarity(self.before, wallet(image))
                ready = (not dialog and merchant >= .90 and correlation < .98 and
                         time.monotonic()-self.confirmed_at >= 1.8)
                self.hits = self.hits+1 if ready else 0
                if self.hits >= 3:
                    self.save(image, 'wallet_changed')
                    self.log(f'확인창 사라짐·재화 표시 변화 확인(상관계수 {correlation:.3f}) → 상점 닫기')
                    click_client_point(self.handle, .974, .035)
                    self.advance('closed', 8)
            elif self.phase == 'clear_notice':
                self.hits = self.hits+1 if not dialog and merchant >= .90 else 0
                if self.hits >= 2:
                    click_client_point(self.handle, .974, .035)
                    self.log('구매 불필요 알림 닫힘·상점 연속 확인 → 상점 닫기 1회')
                    self.advance('closed', 8)
            elif self.phase == 'closed':
                self.hits = self.hits+1 if merchant < .70 and not dialog else 0
                if self.hits >= 2:
                    message = ('구매 가능한 아이템 없음 확인·상점 닫힘 완료 → 추가 구매 없이 보급 다음 단계로 진행합니다.'
                               if self.no_purchase else
                               '구매 확인·재화 표시 변화·상점 닫힘 확인 완료. 구매 품목과 수량은 게임의 저장된 설정을 사용합니다.')
                    self.finish(message, image, success=True)
                    if self.owner.supply_runner.active:
                        self.owner.supply_runner.purchased()
                    return
            self.schedule()
        except Exception as exc:
            self.finish(str(exc), image)
