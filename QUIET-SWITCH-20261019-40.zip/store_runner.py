"""One-shot storage transaction with observed dialog and inventory change."""
import time
from datetime import datetime
from pathlib import Path
import numpy as np
from window_link import capture
from game_actions import check_game_view, click_client_point
from vision import from_capture, warehouse, deposit_dialog, no_store_items


class StoreRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def schedule(self):
        self.job = self.owner.after(600, self.tick)

    def log(self, message):
        self.owner.town_log('[자동 보관] ' + message)

    def start(self, handle=None, chained=False):
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = handle or self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        self.active = True
        self.phase = 'warehouse'
        self.hits = 0
        self.notice_hits = 0
        self.notice_dismissed = False
        self.limit = time.monotonic()+20
        self.countdown(3)

    def countdown(self, seconds):
        self.job = None
        if not self.active:
            return
        if seconds:
            self.log(f'{seconds}초 후 시작 · 창고를 연 게임 화면을 활성화하세요.')
            self.job = self.owner.after(1000, lambda: self.countdown(seconds-1))
        else:
            self.tick()

    def finish(self, message, image=None, success=False):
        if self.owner.supply_runner.active and not success:
            self.owner.supply_runner.fail(message, image)
        self.stop()
        if image is not None:
            try:
                folder = Path(__file__).resolve().parent/'diagnostics'
                folder.mkdir(exist_ok=True)
                image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_store_{self.phase}.png')
            except OSError:
                pass
        self.log(message)

    @staticmethod
    def bag(image):
        return np.asarray(image.convert('RGB'), dtype=np.int16)[85:520, 585:795]

    def advance(self, phase, timeout):
        self.phase = phase
        self.hits = 0
        self.limit = time.monotonic()+timeout

    def tick(self):
        self.job = None
        if not self.active:
            return
        image = None
        try:
            if self.owner.window_link.hwnd != self.handle:
                raise RuntimeError('연결 대상이 바뀌어 중지했습니다.')
            check_game_view(self.handle)
            image = from_capture(capture(self.handle))
            if time.monotonic() > self.limit:
                raise RuntimeError(f'{self.phase} 확인 시간 초과 · 같은 요청을 반복하지 않습니다.')
            store = warehouse(image)
            title, question = deposit_dialog(image)
            dialog = title >= .82 and question >= .78
            notice_title, notice_body = no_store_items(image)
            notice = notice_title >= .82 and notice_body >= .80
            self.notice_hits = self.notice_hits+1 if notice else 0
            if notice and not self.notice_dismissed:
                if self.notice_hits >= 2:
                    click_client_point(self.handle, .5, .638)
                    self.notice_dismissed = True
                    self.log('자동 보관할 아이템이 없습니다 알림 연속 확인 → 확인 1회 → 창고 닫기 준비')
                    self.advance('clear_notice', 8)
                self.schedule()
                return
            if self.phase == 'warehouse':
                if dialog:
                    raise RuntimeError('이미 확인창이 열려 있습니다. 닫고 창고 화면에서 다시 시작하세요.')
                self.hits = self.hits+1 if store >= .90 else 0
                if self.hits >= 2:
                    self.before = self.bag(image).copy()
                    detail = click_client_point(self.handle, .925, .95)
                    self.log(f'창고 연속 확인 → 자동 보관 1회 클릭 · {detail}')
                    self.advance('confirm', 10)
            elif self.phase == 'confirm':
                self.hits = self.hits+1 if dialog else 0
                if self.hits >= 2:
                    detail = click_client_point(self.handle, .622, .643)
                    self.log(f'자동 보관 제목·문구 연속 확인({title:.2f}/{question:.2f}) → 확인 1회 · {detail}')
                    self.advance('result', 10)
            elif self.phase == 'result':
                change = float((np.max(np.abs(self.bag(image)-self.before), axis=2) > 30).mean())
                self.hits = self.hits+1 if not dialog and store >= .90 and change >= .005 else 0
                if self.hits >= 2:
                    self.log(f'확인창 닫힘·가방 화면 변화 감지({change:.1%}) → 창고 닫기')
                    click_client_point(self.handle, .974, .035)
                    self.advance('closed', 8)
            elif self.phase == 'clear_notice':
                self.hits = self.hits+1 if not notice and not dialog and store >= .90 else 0
                if self.hits >= 2:
                    click_client_point(self.handle, .974, .035)
                    self.log('알림 닫힘·창고 화면 확인 → 창고 닫기 1회')
                    self.advance('closed', 8)
            elif self.phase == 'closed':
                self.hits = self.hits+1 if store < .70 and not dialog and not notice else 0
                if self.hits >= 2:
                    self.finish('창고 닫힘 확인 완료. 보관 수량 자체는 자동 집계하지 않습니다.', image, success=True)
                    if self.owner.auto_jumo.get() or self.owner.supply_runner.active:
                        self.owner.jumo_runner.start(chained=self.owner.supply_runner.active)
                    return
            self.schedule()
        except Exception as exc:
            self.finish(str(exc), image)
