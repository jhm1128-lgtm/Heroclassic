"""Inspect five configured regions. Never press Enter/entry/payment buttons."""
from datetime import datetime
from pathlib import Path
import json
import time
from window_link import capture
from game_actions import check_game_view, click_client_point, scroll_region_list
from vision import (from_capture, special_screen, special_icon, region_card,
                    selected_card, special_expired, special_remaining, special_floor_selected, shop, warehouse)

KEYS = ('soul', 'city', 'fortress', 'landfill', 'tomb')


def full_card(left, top):
    # The list viewport clips above y=90 and below y=590. A partial
    # terrain match must never be used to select or classify a region.
    return 3 <= left <= 30 and 90 <= top and top+79 <= 590


class SpecialRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, text):
        self.owner.town_log('[특수지역 확인] ' + text)
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'special_check.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} 창{getattr(self, "handle", 0)} {text}\n')
        except OSError:
            pass

    def start(self, chained=False):
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        self.phase = 'open'
        self.index = 0
        self.results = []
        self.hits = 0
        self.scrolled = 0
        self.previous = None
        self.opened_menu = False
        self.clicked_special = False
        self.active = True
        self.deadline = time.monotonic()+90
        self.phase_deadline = time.monotonic()+15
        for row in self.owner.rows[2:7]:
            self.owner.tree.set(row, 'state', '확인 대기')
        self.countdown(3)

    def countdown(self, seconds):
        self.job = None
        if not self.active:
            return
        if seconds:
            self.log(f'{seconds}초 후 시작 · 한밭마을 게임을 활성화하세요. 입장은 누르지 않습니다.')
            self.job = self.owner.after(1000, lambda: self.countdown(seconds-1))
        else:
            self.tick()

    def later(self):
        self.job = self.owner.after(900, self.tick)

    def save(self, image, label):
        folder = Path(__file__).resolve().parent/'diagnostics'
        try:
            folder.mkdir(exist_ok=True)
            filename = f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_special_{label}.png'
            image.save(folder/filename)
            return filename
        except OSError:
            return None

    def finish(self, text, image=None, continuing=False):
        if self.owner.cycle_runner.active and not continuing:
            self.owner.cycle_runner.stop()
        self.stop()
        if image is not None:
            self.save(image, 'final')
        self.log(text)
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            path = folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_special_results.json'
            path.write_text(json.dumps({'hwnd':self.handle, 'regions':self.results}, ensure_ascii=False, indent=2), encoding='utf-8')
        except OSError:
            pass

    def tick(self):
        self.job = None
        if not self.active:
            return
        image = None
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결 창이 바뀌어 중지했습니다.')
            check_game_view(self.handle)
            image = from_capture(capture(self.handle))
            now = time.monotonic()
            if now > self.deadline or now > self.phase_deadline:
                raise RuntimeError(f'{self.phase} 확인 시간 초과 · 판독하지 못한 지역은 완료로 처리하지 않습니다.')
            screen = special_screen(image)
            if self.phase == 'open':
                if screen < .85:
                    self.hits = 0
                if screen >= .85:
                    self.hits += 1
                    if self.hits >= 2:
                        self.phase = 'align_top'
                        self.phase_deadline = now+20
                        self.hits = 0
                        self.scrolled = 0
                        self.log('특수지역 화면 연속 확인 → 목록 위쪽 정렬·영혼의 동굴 전체 표시 확인')
                elif self.clicked_special:
                    pass
                else:
                    score, x, y = special_icon(image)
                    if score >= .82:
                        click_client_point(self.handle, x/800, y/600)
                        self.clicked_special = True
                        self.log('오른쪽 메뉴의 특수지역 클릭 → 화면 확인 대기')
                    elif not self.opened_menu:
                        if shop(image) >= .88 or warehouse(image) >= .88:
                            raise RuntimeError('상점/창고를 닫은 한밭마을 화면에서 시작하세요.')
                        click_client_point(self.handle, .976, .963)
                        self.opened_menu = True
                        self.log('오른쪽 전체 메뉴 열기 → 특수지역 아이콘 확인 대기')
            else:
                if screen < .85:
                    raise RuntimeError('특수지역 화면이 확인되지 않아 중지했습니다.')
                if self.phase == 'align_top':
                    score, left, top = region_card(image, 'soul')
                    ready = score >= .85 and full_card(left, top) and top <= 120
                    self.hits = self.hits+1 if ready else 0
                    if self.hits >= 2:
                        self.phase = 'find'
                        self.phase_deadline = now+16
                        self.hits = 0
                        self.scrolled = 0
                        self.log('영혼의 동굴 카드 전체 표시 연속 확인 → 위에서부터 다섯 지역 검사')
                    elif not ready:
                        if self.scrolled >= 6:
                            raise RuntimeError('목록 위쪽 정렬 후 첫 지역 전체 표시를 확인하지 못했습니다. 완료로 처리하지 않습니다.')
                        scroll_region_list(self.handle, 240)
                        self.scrolled += 1
                        self.log(f'첫 지역 글자·카드 전체 표시를 위해 위로 스크롤 {self.scrolled}/6 · 후보 {score:.2f}, 위치 ({left},{top})')
                    self.later()
                    return
                key = KEYS[self.index]
                name, floor = self.owner.routes[self.index]
                score, left, top = region_card(image, key)
                if self.phase in ('find', 'prepare_find'):
                    if score >= .78 and full_card(left, top):
                        click_client_point(self.handle, (left+95)/800, (top+38)/600)
                        self.phase = 'prepare_confirm' if self.phase == 'prepare_find' else 'inspect'
                        self.phase_deadline = now+8
                        self.previous = None
                        self.hits = 0
                        self.log(f'{name} 목록 확인 {score:.2f} → 선택 · 입장 버튼은 누르지 않습니다.')
                    elif self.scrolled < 4:
                        scroll_region_list(self.handle, 240 if self.index == 0 or self.phase == 'prepare_find' else -240)
                        self.scrolled += 1
                        self.log(f'{name} 찾기 · 목록 스크롤 {self.scrolled}/4')
                    else:
                        raise RuntimeError(f'{name} 목록을 찾지 못했습니다({score:.2f}). 다음 지역을 완료로 간주하지 않습니다.')
                elif score >= .78 and full_card(left, top) and selected_card(image, left, top):
                    card, detail = special_expired(image, left, top)
                    expired = card >= .78 and detail >= .78
                    remaining, minute, second = special_remaining(image)
                    inconsistent = (card >= .78) != (detail >= .78) or (expired and remaining)
                    if inconsistent:
                        expired, remaining = False, False
                    classification = '판독 불일치' if inconsistent else '완료·건너뛰기' if expired else '남은 시간 있음' if remaining else '시간 판독 필요'
                    if self.phase == 'prepare_confirm':
                        self.hits = self.hits+1 if remaining and not expired else 0
                        if self.hits >= 2:
                            self.target_floor = int(floor.replace('층',''))
                            y = {1:484, 2:421, 3:358, 4:294}[self.target_floor]
                            click_client_point(self.handle, 681/800, y/600)
                            self.phase = 'floor_check'
                            self.phase_deadline = now+8
                            self.hits = 0
                            self.log(f'{name} {floor} 선택 → 선택 표시 확인 대기 · 입장은 누르지 않습니다.')
                        self.later()
                        return
                    if self.phase == 'floor_check':
                        valid = remaining and not expired and special_floor_selected(image, self.target_floor)
                        self.hits = self.hits+1 if valid else 0
                        if self.hits >= 2:
                            self.save(image, key+'_floor_ready')
                            self.owner.tree.set(self.owner.rows[self.index+2], 'state', floor+' 준비')
                            self.finish(f'{name} {floor} 선택 확인 완료 · 남은 시간 표시 확인.', image, continuing=True)
                            if self.owner.auto_enter.get() or self.owner.cycle_runner.active:
                                self.owner.entry_runner.start(chained=self.owner.cycle_runner.active)
                            return
                        self.later()
                        return
                    self.hits = self.hits+1 if classification == self.previous else 1
                    self.previous = classification
                    if self.hits >= 2:
                        picture = self.save(image, key)
                        self.results.append({'name':name, 'floor':floor, 'expired':expired,
                                             'state':classification, 'remaining':remaining, 'timer_unit_1_score':round(minute,3), 'timer_unit_2_score':round(second,3), 'card_score':round(card,3),
                                             'detail_score':round(detail,3), 'image':picture})
                        self.owner.tree.set(self.owner.rows[self.index+2], 'state', '완료·건너뜀' if expired else '시간 남음' if remaining else '확인 필요')
                        self.log(f'{name} {floor}: {classification} · 목록 {card:.2f}/상세 {detail:.2f}')
                        self.index += 1
                        if self.index >= len(KEYS):
                            if self.owner.cycle_runner.active:
                                required = self.owner.cycle_runner.required_expired
                                if required is not None and not self.results[required]['expired']:
                                    self.finish(self.owner.routes[required][0]+'의 만료를 확인하지 못했습니다. 다음 지역 입장·재입장은 하지 않습니다.', image)
                                    return
                            skipped = sum(result['expired'] for result in self.results)
                            first = next((i for i,result in enumerate(self.results) if result['remaining']), None)
                            if self.owner.cycle_runner.active and any(not r['expired'] and not r['remaining'] for r in self.results):
                                self.finish('만료·남은 시간 판독이 불확실한 지역이 있어 자동 순회를 중지합니다.', image)
                                return
                            if first is None and skipped == 5 and self.owner.cycle_runner.active:
                                self.finish('다섯 지역 모두 만료 확인', image, continuing=True)
                                self.owner.cycle_runner.all_expired(image)
                                return
                            if first is None:
                                self.finish(f'다섯 지역 확인 종료 · 만료 {skipped}곳 / 추가 확인 {5-skipped}곳. 입장·일반 사냥 복귀는 실행하지 않습니다.', image)
                                return
                            self.index = first
                            self.phase = 'prepare_find'
                            self.phase_deadline = now+18
                            self.scrolled = 0
                            self.hits = 0
                            self.previous = None
                            self.log(f'남은 시간이 확인된 첫 지역 {self.owner.routes[first][0]}로 돌아가 지정 층을 준비합니다.')
                            self.later()
                            return
                        self.phase = 'find'
                        self.phase_deadline = now+16
                        self.scrolled = 0
                else:
                    self.hits = 0
            self.later()
        except Exception as exc:
            self.finish(str(exc), image)
