from admin_launch import BUILD, is_admin, launch_as_admin
import sys
from pathlib import Path

if __name__ == "__main__" and not launch_as_admin(__file__):
    raise SystemExit(0)

import tkinter as tk
from tkinter import ttk
from datetime import datetime
from window_link import WindowLink, windows, bounds
from npc_runner import NpcRunner
from store_runner import StoreRunner
from buy_runner import BuyRunner
from special_runner import SpecialRunner
from entry_runner import EntryRunner
from auto_runner import AutoRunner
from cycle_runner import CycleRunner
from general_runner import GeneralRunner
from dual_runner import DualRunner
from focus_runner import FocusRunner
from supply_runner import SupplyRunner
from daily_scheduler import DailyScheduler
from work_coordinator import WorkCoordinator
from event_runner import EventRunner
from event_schedule import EventScheduler

ROUTES = [('영혼의 동굴', '2층'), ('부패한 도성', '4층'), ('행주산성', '3층'), ('전리품 매립지', '3층'), ('조선왕릉', '1층')]

class Profile(ttk.Frame):
    def __init__(self, parent, name, right=False):
        super().__init__(parent)
        self.right=right
        self.routes = ROUTES[:-1] + [('조선왕릉', '2층' if right else '1층')]
        self.general_key = 'ship' if right else 'wol'
        self.destination = '월정사 · 대웅전 입구' if not right else '대한해협 · 왜구 함선1 내부'
        self.travel = 'MAP → 전체 → 월정사 → 11. 대웅전 입구 → 이동하기 → AUTO' if not right else 'MAP → 전체 → 대한해협 → 07. 왜구 함선1 내부 → 이동하기 → AUTO' 
        self.pending = None
        self.index = 0
        self.running = False
        self.return_mode = False
        self.map_trial = False
        self.map_method = 'key'
        self.town_target = None
        self.town_selected_at = 0
        self.town_job = None
        self.npc_runner = NpcRunner(self)
        self.jumo_runner = NpcRunner(self, kind="jumo")
        self.auto_jumo = tk.BooleanVar(value=True)
        self.store_runner = StoreRunner(self)
        self.buy_runner = BuyRunner(self)
        self.special_runner = SpecialRunner(self)
        self.entry_runner = EntryRunner(self)
        self.auto_runner = AutoRunner(self)
        self.cycle_runner = CycleRunner(self)
        self.general_runner = GeneralRunner(self)
        self.supply_runner = SupplyRunner(self)
        self.event_runner=EventRunner(self)
        self.event_scheduler=EventScheduler(self)
        self.event_enabled=tk.BooleanVar(value=True)
        self.event_status=tk.StringVar(value='이벤트 예약 꺼짐')
        self.daily_scheduler = DailyScheduler(self)
        self.reservation_status = tk.StringVar(value="매일 예약 꺼짐")
        self.auto_enter = tk.BooleanVar(value=True)
        self.auto_buy = tk.BooleanVar(value=True)
        self.auto_store = tk.BooleanVar(value=True)
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', font=('맑은 고딕', 10))
        style.configure('TFrame', background='#171d28')
        style.configure('TLabel', background='#171d28', foreground='#e5eaf2')
        style.configure('Title.TLabel', font=('맑은 고딕', 18, 'bold'))
        style.configure('Sub.TLabel', foreground='#a9b5c9')
        style.configure('TButton', padding=9)
        style.configure('Treeview', rowheight=31, background='#222c3b', fieldbackground='#222c3b', foreground='#edf2fa')
        self.status = tk.StringVar(value='대기 중 · 위에서 실행 모드를 선택하세요.')
        self.supply = tk.StringVar(value='04:50')
        self.start = tk.StringVar(value='05:01')
        self.auto_npc = tk.BooleanVar(value=True)
        self.scroll_canvases = []
        pages = ttk.Notebook(self)
        self.pages = pages
        pages.pack(fill='both', expand=True)
        dashboard_page = ttk.Frame(pages)
        settings_page = ttk.Frame(pages)
        diagnostics_page = ttk.Frame(pages)
        pages.add(dashboard_page, text='진행 현황')
        pages.add(settings_page, text='설정')
        pages.add(diagnostics_page, text='실행 기록')
        main, self.canvas = self.scrolled_body(dashboard_page)
        settings,self.settings_canvas=self.scrolled_body(settings_page)
        diagnostics, self.diagnostic_canvas = self.scrolled_body(diagnostics_page)
        self.bind_all('<MouseWheel>', self.scroll_wheel, add='+')

        ttk.Label(main, text='게임 연결', font=('맑은 고딕',12,'bold')).pack(anchor='w')
        self.window_link = WindowLink(main, right=right)
        self.window_link.pack(fill='x', pady=(6,12))
        summary = ttk.Frame(main)
        summary.pack(fill='x')
        ttk.Label(summary, text='일반 사냥  '+self.destination, style='Sub.TLabel').pack(anchor='w')
        ttk.Label(summary, text='조선왕릉  '+self.routes[-1][1]+'   ·   양쪽 교대 간격 1분', style='Sub.TLabel').pack(anchor='w', pady=(2,10))
        ttk.Label(main, text='현재 진행', font=('맑은 고딕',12,'bold')).pack(anchor='w')
        self.quick_status = ttk.Label(main, textvariable=self.status, wraplength=920)
        self.quick_status.pack(fill='x', pady=(6,12))
        self.tree = ttk.Treeview(main, columns=('time','place','action','state'), displaycolumns=('place','state'), show='headings', height=8, selectmode='browse')
        for key,title,width in [('time','시간',100),('place','지역 / 대상',430),('action','동작',300),('state','진행 상태',190)]:
            self.tree.heading(key,text=title)
            self.tree.column(key,width=width,stretch=key=='place')
        self.tree.pack(fill='x')
        self.rows = [self.tree.insert('', 'end', values=('04:50','한밭마을 · 복자할매','창고 → 자동 보관 → 확인 → 닫기','대기')),
                     self.tree.insert('', 'end', values=('보관 후','한밭마을 · 주모','자동 구매 → 확인 → 닫기','대기'))]
        for i,(place,floor) in enumerate(self.routes):
            self.rows.append(self.tree.insert('', 'end', values=('05:01' if i==0 else '복귀 확인 후',f'{i+1}. {place} {floor}','입장 → AUTO → 시간 소진 → 복귀','대기')))
        self.rows.append(self.tree.insert('', 'end', values=('전체 완료 후',self.destination,self.travel,'대기')))
        general_controls = ttk.Frame(main)
        general_controls.pack(fill='x', pady=(0,8))
        ttk.Button(general_controls,text='일반 사냥 재개',command=lambda:self.winfo_toplevel().launch_general(self.winfo_toplevel().profiles.index(self))).pack(side='left')
        ttk.Button(general_controls,text='특수지역으로',command=lambda:self.winfo_toplevel().launch_remaining(self.winfo_toplevel().profiles.index(self))).pack(side='left',padx=8)
        ttk.Button(general_controls,text='이 캐릭터 정지',command=lambda:self.stop(cancel_schedule=True)).pack(side='left')
        daily_controls=ttk.Frame(main);daily_controls.pack(fill='x',pady=(0,8))
        ttk.Button(daily_controls,text='매일 자동 반복 시작 (04:50 / 05:01)',command=lambda:self.winfo_toplevel().arm_daily(self.winfo_toplevel().profiles.index(self))).pack(side='left')
        ttk.Button(daily_controls,text='예약 끄기',command=self.daily_scheduler.stop).pack(side='left',padx=8)
        ttk.Label(main,textvariable=self.reservation_status,style='Sub.TLabel').pack(anchor='w')
        ttk.Label(main,textvariable=self.event_status,style='Sub.TLabel',wraplength=920).pack(anchor='w',pady=4)
        ttk.Label(main,text='자동 반복 시작은 현재 사냥을 유지하며 다음 04:50을 기다립니다. 종료·전체 정지 시 예약은 꺼집니다.',style='Sub.TLabel',wraplength=920).pack(anchor='w')
        ttk.Label(main,text=BUILD+' · 관리자 권한: '+('확인됨' if is_admin() else '없음'),style='Sub.TLabel').pack(anchor='w',pady=(8,0))

        ttk.Label(settings,text='캐릭터별 사냥 설정',style='Title.TLabel').pack(anchor='w',pady=(0,12))
        for place,floor in self.routes:
            ttk.Label(settings,text=place+'   '+floor).pack(anchor='w',pady=3)
        ttk.Label(settings,text='일반 사냥: '+self.destination).pack(anchor='w',pady=(8,16))
        ttk.Label(settings,text='매일 예약 시각 · 한국 시간',font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(18,8))
        times=ttk.Frame(settings)
        times.pack(fill='x')
        for label,var in [('보관·구매',self.supply),('특수지역',self.start)]:
            ttk.Label(times,text=label).pack(side='left',padx=(0,8))
            ttk.Entry(times,textvariable=var,width=8).pack(side='left',padx=(0,20))
        reservation_controls=ttk.Frame(settings);reservation_controls.pack(fill='x',pady=10)
        ttk.Button(reservation_controls,text='이 캐릭터 매일 예약 켜기',command=self.daily_scheduler.arm).pack(side='left')
        ttk.Button(reservation_controls,text='예약 끄기',command=self.daily_scheduler.stop).pack(side='left',padx=8)
        ttk.Label(settings,textvariable=self.reservation_status).pack(anchor='w')
        ttk.Label(settings,text='양쪽 예약 가능 · 각 창의 지역·완료 상태를 따로 관리하며 실제 조작은 한 창씩 진행합니다.',style='Sub.TLabel',wraplength=900).pack(anchor='w',pady=4)
        ttk.Label(settings,text='특수지역 종료 후 다음 남은 지역 → 다섯 곳 완료 후 일반 사냥·AUTO',style='Sub.TLabel').pack(anchor='w',pady=4)
        ttk.Label(settings,text='이벤트 특수지역 · 일반 사냥에서 참여 후 일반 사냥 복귀',font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(12,4))
        def event_toggle():
            if self.event_enabled.get() and self.daily_scheduler.active:self.event_scheduler.arm()
            else:self.event_scheduler.stop()
        ttk.Checkbutton(settings,text='이벤트 예약 사용 · 현재 열려 있는 이벤트도 참여',variable=self.event_enabled,command=event_toggle).pack(anchor='w')
        ttk.Label(settings,text='매일 16:00~17:00 · 특수지역 > 버려진 동굴 1층').pack(anchor='w',pady=3)
        if right:
            ttk.Label(settings,text='수요일 제외 매일 20:00~22:00 · 특수지역 > 가덕도왜성 1층').pack(anchor='w',pady=3)
            ttk.Label(settings,text='매주 수요일 19:00~23:00 · 월드지역 > 저주받은 니조성 1층').pack(anchor='w',pady=3)

        ttk.Label(diagnostics,text='상세 기록',font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(14,4))
        self.log=tk.Text(diagnostics,height=12,bg='#101620',fg='#bcd0e9',relief='flat',font=('맑은 고딕',10),state='disabled')
        self.log.pack(fill='both',expand=True)
        self.log.configure(state='normal')
        self.log.insert('end',f'[실행 정보] {BUILD} · 관리자={is_admin()} · 파일={Path(__file__).resolve()} · Python={sys.executable}\n')
        self.log.configure(state='disabled')

    def scrolled_body(self,parent):
        scroll=ttk.Scrollbar(parent,orient='vertical');scroll.pack(side='right',fill='y')
        canvas=tk.Canvas(parent,bg='#171d28',highlightthickness=0,yscrollcommand=scroll.set)
        canvas.pack(side='left',fill='both',expand=True);scroll.configure(command=canvas.yview)
        body=ttk.Frame(canvas,padding=16)
        content=canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda event:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda event:canvas.itemconfigure(content,width=event.width))
        self.scroll_canvases.append(canvas)
        return body,canvas

    def scroll_wheel(self,event):
        if not self.winfo_ismapped() or isinstance(event.widget,(tk.Text,ttk.Treeview,ttk.Combobox)):
            return
        current=event.widget
        while current is not None and current is not self:
            if current in self.scroll_canvases:
                current.yview_scroll(-int(event.delta/120),'units')
                return 'break'
            current=getattr(current,'master',None)

    def town_log(self, message):
        self.status.set(message)
        self.log.configure(state='normal')
        self.log.insert('end', f'{datetime.now():%H:%M:%S}  [한밭 이동] {message}\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def stop(self, cancel_schedule=False):
        self.event_runner.stop()
        if hasattr(self, "supply_runner"):
            self.supply_runner.stop()
        if cancel_schedule and hasattr(self, "daily_scheduler"):
            self.daily_scheduler.stop()
        if hasattr(self, "general_runner"):
            self.general_runner.stop()
        if hasattr(self, "cycle_runner"):
            self.cycle_runner.stop()
        if hasattr(self, "auto_runner"):
            self.auto_runner.stop()
        if hasattr(self, "entry_runner"):
            self.entry_runner.stop()
        if hasattr(self, "special_runner"):
            self.special_runner.stop()
        if hasattr(self, "buy_runner"):
            self.buy_runner.stop()
        if hasattr(self, "jumo_runner"):
            self.jumo_runner.stop()
        if hasattr(self, "store_runner"):
            self.store_runner.stop()
        if hasattr(self, "npc_runner"):
            self.npc_runner.stop()
        self.town_target = None
        if self.town_job:
            self.after_cancel(self.town_job)
            self.town_job = None
        if self.pending:
            self.after_cancel(self.pending)
            self.pending = None
        if self.running and self.index and not self.map_trial:
            self.index -= 1
            self.tree.set(self.rows[self.index], 'state', '정지')
        self.running = False
        self.map_trial = False
        self.status.set('관리 동작 정지 · 게임 AUTO는 그대로 유지됩니다.')

    def close(self):
        self.stop()
        self.destroy()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f'HeroOfChosunClassic · 두 캐릭터 일정 관리 · {BUILD}')
        self.geometry('1040x800')
        self.minsize(960, 650)
        self.configure(bg='#171d28')
        header = ttk.Frame(self, padding=(20, 10))
        header.pack(fill='x')
        self.focus_runner = FocusRunner(self)
        self.mode = tk.StringVar(value='정지')
        ttk.Label(header, textvariable=self.mode).pack(side='left')
        ttk.Button(header, text='왼쪽만 예약', command=lambda: self.run_single(0)).pack(side='left', padx=8)
        ttk.Button(header, text='오른쪽만 예약', command=lambda: self.run_single(1)).pack(side='left')
        ttk.Button(header, text='필요한 창만 전환', command=lambda: self.dual_runner.start()).pack(side='right', padx=8)
        ttk.Button(header, text='■ 전체 정지 (Esc)', command=self.stop_all).pack(side='right')
        daily_header=ttk.Frame(self,padding=(20,0,20,8));daily_header.pack(fill='x')
        ttk.Button(daily_header,text='양쪽 매일 예약 시작',command=self.arm_both_daily).pack(side='left')
        ttk.Label(daily_header,text='04:50 보급 · 05:01 특수지역 · 일반 사냥 중 전환 쉼',style='Sub.TLabel').pack(side='left',padx=12)
        notebook = ttk.Notebook(self)
        self.notebook = notebook
        notebook.pack(fill='both', expand=True)
        self.profiles = []
        for name, right in [('왼쪽 캐릭터', False), ('오른쪽 캐릭터', True)]:
            profile = Profile(notebook, name, right)
            self.profiles.append(profile)
            notebook.add(profile, text=name)
        self.dual_runner = DualRunner(self)
        self.work_coordinator = WorkCoordinator(self)
        notebook.bind('<<NotebookTabChanged>>', self.auto_connect)
        self.after_idle(self.auto_connect)
        self.bind('<Escape>', lambda event: self.stop_all())
        self.protocol('WM_DELETE_WINDOW', self.close)

    def run_single(self, index):
        if self.work_coordinator.active or self.work_coordinator.pending or any(self.work_coordinator.busy(p) for p in self.profiles):
            self.profiles[index].town_log('진행 중인 조작이 끝난 뒤 예약 모드를 변경하세요.')
            return
        self.auto_connect()
        if not self.profiles[index].window_link.hwnd:
            self.profiles[index].town_log('선택한 게임 창을 먼저 연결하세요. 기존 예약은 유지합니다.')
            return
        for i,profile in enumerate(self.profiles):
            if i != index:
                profile.daily_scheduler.stop()
                profile.stop()
        self.dual_runner.stop()
        self.arm_daily(index)
        if self.profiles[index].daily_scheduler.active:
            self.mode.set(('왼쪽' if index == 0 else '오른쪽')+'만 매일 예약')

    def launch_action(self, index, action, label, failed=None, scheduled=False):
        self.auto_connect()
        self.work_coordinator.submit(index,label,action,failed,scheduled=scheduled)

    def arm_both_daily(self):
        self.auto_connect()
        handles=[p.window_link.hwnd for p in self.profiles]
        if not all(handles) or len(set(handles)) != 2:
            self.profiles[0].town_log('[양쪽 예약] 서로 다른 두 게임 창을 먼저 연결하세요.')
            return
        if self.work_coordinator.active or self.work_coordinator.pending or any(self.work_coordinator.busy(p) for p in self.profiles):
            self.profiles[0].town_log('[양쪽 예약] 진행 중인 조작이 끝난 뒤 예약을 켜세요.')
            return
        for index in range(2):
            self.arm_daily(index)
        if all(p.daily_scheduler.active for p in self.profiles) and not self.dual_runner.active:
            self.dual_runner.start()

    def arm_daily(self, index):
        self.auto_connect()
        profile=self.profiles[index]
        profile.supply.set('04:50')
        profile.start.set('05:01')
        profile.daily_scheduler.arm()

    def launch_supply(self, index, scheduled=False):
        profile=self.profiles[index]
        self.launch_action(index, lambda:profile.supply_runner.start(scheduled=scheduled),
                           ('예약 보급' if scheduled else '04:50 가정 시험'),
                           profile.daily_scheduler.supply_failed if scheduled else None,
                           scheduled=scheduled)

    def launch_remaining(self, index, scheduled=False):
        profile=self.profiles[index]
        self.launch_action(index, lambda:profile.cycle_runner.start_remaining(chained=True),'특수지역 재개',scheduled=scheduled)

    def launch_general(self, index):
        profile=self.profiles[index]
        self.launch_action(index, lambda:profile.general_runner.start(chained=True),'일반 사냥 재개')

    def auto_connect(self, event=None):
        if not self.profiles or (hasattr(self, "focus_runner") and self.focus_runner.active) or (hasattr(self, "dual_runner") and self.dual_runner.active):
            return
        # Tab changes must not redirect or invalidate an operation in progress.
        if any(p.supply_runner.active or p.general_runner.active or p.cycle_runner.active or p.running or p.npc_runner.active or p.store_runner.active or p.jumo_runner.active or p.buy_runner.active or p.special_runner.active or p.entry_runner.active or p.auto_runner.active for p in self.profiles):
            return
        entries = windows()
        handles = {handle for handle, _ in entries}
        visible = []
        for handle, label in entries:
            try:
                x, y, width, height = bounds(handle)
                visible.append((x, handle, label))
            except RuntimeError:
                pass
        visible.sort()
        for profile in self.profiles:
            link = profile.window_link
            if link.hwnd and link.hwnd not in handles:
                link.hwnd = None
            link.refresh()
        if not visible:
            for profile in self.profiles:
                link = profile.window_link
                if link.hwnd:
                    link.update_state()
                else:
                    link.state.set('게임 창이 없거나 최소화되어 있습니다. 사용할 게임을 복원하고 자동 지정을 누르세요.')
            return
        if len(visible) == 1:
            handle = visible[0][1]
            owner = next((p for p in self.profiles if p.window_link.hwnd == handle), None)
            if owner is None:
                selected = self.notebook.index(self.notebook.select())
                owner = self.profiles[selected]
                owner.window_link.hwnd = handle
            owner.window_link.refresh()
            for profile in self.profiles:
                link = profile.window_link
                if profile is not owner and not link.hwnd:
                    link.state.set('현재 보이는 게임은 다른 탭에 연결되어 있습니다. 해당 탭을 사용하거나 다른 게임을 복원하세요.')
            return
        # Preserve valid existing identities, including manually selected windows.
        assigned = {p.window_link.hwnd for p in self.profiles if p.window_link.hwnd}
        if len(assigned) == 2 and assigned.issubset(handles):
            return
        for profile, (_, handle, _) in zip(self.profiles, visible):
            link = profile.window_link
            link.hwnd = handle
            link.refresh()

    def stop_all(self, cancel_schedules=True):
        if hasattr(self,'work_coordinator'):
            self.work_coordinator.stop()
        if cancel_schedules:
            for profile in self.profiles:
                profile.daily_scheduler.stop()
        if hasattr(self, "focus_runner"):
            self.focus_runner.stop()
        if hasattr(self, "mode"):
            self.mode.set("정지")
        if hasattr(self, "dual_runner"):
            self.dual_runner.stop()
        for profile in self.profiles:
            profile.stop()

    def close(self):
        self.stop_all()
        self.destroy()

if __name__ == '__main__':
    App().mainloop()
