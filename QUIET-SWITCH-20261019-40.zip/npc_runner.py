"""Bounded, observable town-to-warehouse trial; no item transactions."""
import time
from pathlib import Path
from datetime import datetime
from window_link import capture
from game_actions import check_game_view, step_right, step_up, step_direction, click_client_point
from vision import from_capture, town, npc, warehouse, jumo, shop, quest_travel, jumo_approach, npc_visual


class NpcRunner:
    def __init__(self, owner, kind="grandma"):
        self.owner = owner
        self.kind = kind
        self.job = None
        self.active = False
        self.handle = None

    def stop(self):
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, text):
        label = '주모' if self.kind == 'jumo' else '복자할매'
        self.owner.town_log(label+' · '+text)
        try:
            folder=Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'npc_search.log').open('a',encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} {label} {text}\n')
        except OSError:
            pass

    def schedule(self, milliseconds, callback):
        self.job = self.owner.after(milliseconds, callback)

    def start(self, chained=False):
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        self.active = True
        self.steps = 0
        self.misses = 0
        self.occlusion_wait = 0
        self.max_steps = 32
        self.previous = None
        self.clicks = 0
        self.town_hits = 0
        self.town_misses = 0
        # The Jumo action is the next leg from the known town/warehouse position.
        # Do not block that leg on the minimap label that changes after walking.
        self.town_verified = self.kind == 'jumo'
        self.quest_hits = 0
        self.quest_cancelled = False
        self.quest_wait = False
        self.quest_deadline = 0
        self.warehouse_hits = 0
        self.verify_until = None
        self.deadline = time.monotonic() + 90
        self.countdown(3)

    def countdown(self, seconds):
        self.job = None
        if not self.active:
            return
        if seconds:
            self.log(f'{seconds}초 후 시작 · 한밭마을 게임 화면을 활성화하고 메뉴를 닫으세요.')
            self.schedule(1000, lambda: self.countdown(seconds-1))
        else:
            self.tick()

    def finish(self, text, success=False):
        if self.owner.supply_runner.active and not success:
            self.owner.supply_runner.fail(text)
        self.stop()
        self.log(text)

    def tick(self):
        self.job = None
        if not self.active:
            return
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결 창이 변경되어 중지했습니다.')
            if time.monotonic() > self.deadline:
                raise RuntimeError('90초 제한에 도달해 중지했습니다.')
            check_game_view(self.handle)
            image = from_capture(capture(self.handle))
            if self.kind == 'jumo':
                travel_score = quest_travel(image)
                if travel_score >= .86:
                    self.quest_hits += 1
                    if self.quest_wait:
                        if time.monotonic() > self.quest_deadline:
                            raise RuntimeError('메인퀘스트 이동창 취소가 확인되지 않아 중지했습니다.')
                    elif self.quest_cancelled:
                        raise RuntimeError('메인퀘스트 이동창이 다시 나타나 중지했습니다. 확인은 누르지 않습니다.')
                    elif self.quest_hits >= 2:
                        click_client_point(self.handle, .38, .638)
                        self.quest_cancelled = True
                        self.quest_wait = True
                        self.quest_deadline = time.monotonic()+5
                        self.previous = None
                        self.verify_until = None
                        self.log('메인퀘스트 이동창 연속 확인 → 취소 1회 · 주모 탐색 재개 대기')
                    self.schedule(700, self.tick)
                    return
                if self.quest_wait:
                    self.quest_wait = False
                    self.log('메인퀘스트 이동창 사라짐 확인 · 주모를 UI 밖으로 옮겨 탐색합니다.')
                self.quest_hits = 0
            if self.kind == 'jumo' and warehouse(image) >= .90:
                raise RuntimeError('창고 또는 창고 알림이 아직 열려 있습니다. 위쪽 자동 보관 → 확인 → 창고 닫기를 사용하세요.')
            store_score = shop(image) if self.kind == "jumo" else warehouse(image)
            self.warehouse_hits = self.warehouse_hits+1 if store_score >= .90 else 0
            if self.warehouse_hits >= 2:
                self.save(image, 'shop' if self.kind == 'jumo' else 'warehouse')
                label = '주모 회복제 상점' if self.kind == 'jumo' else '창고'
                self.finish(f'{label} 화면 연속 확인 완료 · 유사도 {store_score:.2f}', success=True)
                if self.kind != 'jumo' and (self.owner.auto_store.get() or self.owner.supply_runner.active):
                    self.owner.store_runner.start(self.handle, chained=self.owner.supply_runner.active)
                elif self.kind == 'jumo' and (self.owner.auto_buy.get() or self.owner.supply_runner.active):
                    self.owner.buy_runner.start(self.handle, chained=self.owner.supply_runner.active)
                return
            if self.verify_until is not None:
                if time.monotonic() > self.verify_until:
                    self.save(image, 'unconfirmed')
                    raise RuntimeError('NPC 클릭 후 대상 창을 확인하지 못해 중지했습니다. 추가 클릭하지 않습니다.')
                self.schedule(600, self.tick)
                return
            if self.warehouse_hits:
                self.schedule(600, self.tick)
                return
            if not self.town_verified:
                town_score = town(image)
                # Terrain behind the minimap header changes while walking. It is
                # diagnostic evidence only, never a mandatory town-name condition.
                town_confirmed = town_score >= .78
                self.town_hits = self.town_hits+1 if town_confirmed else 0
                if not town_confirmed:
                    self.town_misses += 1
                    if self.town_misses >= 3:
                        self.save(image, 'town_unconfirmed')
                        raise RuntimeError(f'한밭마을 글자 확인 3회 미달({town_score:.2f}) · 이동 없이 중지')
                    self.log(f'마을 글자 재확인 {self.town_misses}/3 · {town_score:.2f} · 이동 입력 대기')
                    self.schedule(600, self.tick)
                    return
                self.town_misses = 0
                if self.town_hits < 2:
                    self.log(f'한밭마을 글자 후보 {town_score:.2f} · 다음 화면 재확인')
                    self.schedule(600, self.tick)
                    return
                self.town_verified = True
                self.log('한밭마을 시작 위치 확인 완료 · 이번 탐색 동안 유지하고 복자할매를 찾습니다.')
            score, x, y = jumo(image) if self.kind == 'jumo' else npc(image)
            visual, body_x, body_y, marker = npc_visual(image,self.kind)
            origin = '이름'
            if visual >= .85:
                score,x,y = visual,body_x,body_y-43
                origin = '표시·몸체'
            elif marker >= .88 and score < .85:
                self.previous = None
                self.occlusion_wait += 1
                self.log(f'NPC 표시 확인 {marker:.2f} · 이름/몸체 가림 재확인 {self.occlusion_wait}')
                if self.occlusion_wait <= 2:
                    self.schedule(800,self.tick)
                    return
                approach=jumo_approach(body_x,body_y)
                if approach is None:
                    key=0x41 if self.occlusion_wait%2 else 0x44
                    direction='옆으로 가림 해소'
                else:
                    key,direction=approach
                if self.steps >= self.max_steps:
                    self.save(image,'occluded')
                    raise RuntimeError('NPC 표시가 있으나 몸체 확인이 계속 가려져 중지했습니다. 클릭하지 않았습니다.')
                step_direction(self.handle,key)
                self.steps += 1
                self.log(f'{direction} 0.16초 · 이동 {self.steps}/{self.max_steps}')
                self.schedule(800,self.tick)
                return
            if score >= .85:
                self.misses=0
                self.occlusion_wait=0
                approach=jumo_approach(x,min(y+43,525))
                if approach is not None:
                    if self.steps >= self.max_steps:
                        self.save(image,'hud_overlap')
                        raise RuntimeError('NPC를 안전한 클릭 영역으로 옮기지 못해 중지했습니다.')
                    key,direction=approach
                    self.previous=None
                    step_direction(self.handle,key)
                    self.steps += 1
                    self.log(f'{origin} {score:.2f}·NPC ({x:.0f},{y+43:.0f}) → 중앙 접근 {direction} {self.steps}/{self.max_steps}')
                    self.schedule(800,self.tick)
                    return
            if score >= .85:
                if self.previous and abs(self.previous[0]-x) < 8 and abs(self.previous[1]-y) < 8:
                    self.save(image, 'before_jumo_click' if self.kind == 'jumo' else 'before_grandma_click')
                    detail = click_client_point(self.handle, x/800, min(y+43, 525)/600)
                    self.log(f'{origin} 연속 확인 {score:.2f} · {detail} · 대상 창 확인 대기')
                    self.verify_until = time.monotonic()+8
                    self.schedule(800, self.tick)
                    return
                self.previous = (x, y)
                self.log(f'NPC {origin} 후보 {score:.2f} · 다음 화면에서 다시 확인')
                self.schedule(600, self.tick)
                return
            self.previous = None
            self.misses += 1
            self.occlusion_wait=0
            if self.steps >= self.max_steps:
                self.save(image,'not_found')
                raise RuntimeError('제한된 왕복 탐색에서 NPC를 확인하지 못해 중지했습니다.')
            if self.misses <= 2:
                self.log(f'NPC 화면 재확인 · 이름 {score:.2f}/표시 {marker:.2f} · 이동 잠시 대기')
                self.schedule(700,self.tick)
                return
            primary,reverse = (0x57,0x53) if self.kind=='jumo' else (0x44,0x41)
            side,back = (0x44,0x41) if self.kind=='jumo' else (0x57,0x53)
            plan=[primary]*12+[reverse]*12+[side]*4+[back]*4
            key=plan[self.steps]
            step_direction(self.handle,key)
            self.steps += 1
            self.log(f'왕복 탐색 {chr(key)} 0.16초 {self.steps}/{self.max_steps} · 다음 화면 확인')
            if self.steps%4==0:
                self.save(image,f'search_{self.steps:02d}')
            self.schedule(700,self.tick)
        except Exception as exc:
            self.finish(str(exc))

    def save(self, image, label):
        try:
            folder = Path(__file__).resolve().parent / 'diagnostics'
            folder.mkdir(exist_ok=True)
            path = folder / f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_{label}.png'
            image.save(path)
            self.log(f'확인 화면 저장: {path}')
        except OSError as exc:
            self.log(f'확인 화면 저장 실패: {exc}')
