"""Observe a current special hunt, then inspect remaining daily regions."""
import time
from datetime import datetime
from pathlib import Path
from window_link import capture
from game_actions import check_game_view
from vision import (from_capture, auto_control, special_screen, notice,
                    special_hud_timer, shop, warehouse, quest_travel,
                    purchase_dialog, special_entry_dialog, special_icon)


class CycleRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, message):
        self.owner.town_log('[특수지역 이어가기] '+message)
        folder = Path(__file__).resolve().parent/'diagnostics'
        try:
            folder.mkdir(exist_ok=True)
            with (folder/'special_cycle.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} {message}\n')
        except OSError:
            pass

    def save(self, image, label):
        # Observation begins before SpecialRunner has been started.
        folder = Path(__file__).resolve().parent/'diagnostics'
        try:
            folder.mkdir(exist_ok=True)
            image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_cycle_{label}.png')
        except OSError as exc:
            self.log(f'진단 화면 저장 실패 · {exc}')

    def start_remaining(self, chained=False):
        """Reinspect current game data from town; no remembered expiry required."""
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        self.active = True
        self.phase = 'resume'
        self.required_expired = None
        self.deadline = time.monotonic()+90
        self.log('3초 후 현재 이용시간 재검사 · 한밭마을 또는 열린 특수지역 화면을 활성화하세요. 이전 완료 기록은 사용하지 않습니다.')
        self.job = self.owner.after(3000, self.resume_check)

    def resume_check(self):
        self.job = None
        if not self.active:
            return
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결된 게임 창이 바뀌었습니다.')
            check_game_view(self.handle)
            image = from_capture(capture(self.handle))
            screen = special_screen(image)
            timer = special_hud_timer(image)
            field = auto_control(image)[0]
            menu_open = special_icon(image)[0] >= .82
            self.save(image, 'resume_check')
            self.log(f'재개 화면 점수 · 특수메뉴 {screen:.3f} / 시간표시 {timer:.3f} / 필드 {field:.3f} / 전체메뉴 {menu_open}')
            if screen < .85:
                if timer >= .60 or (field < .78 and not menu_open):
                    self.phase = 'observe'
                    self.hits = 0
                    self.menu_hits = 0
                    self.paused = False
                    self.last_trace = 0
                    self.saved_state = None
                    self.deadline = time.monotonic()+70*60
                    if timer >= .78:
                        self.log('특수지역 시간 표시 확인 · 재입장·AUTO 클릭 없이 종료를 관찰합니다.')
                    else:
                        self.log('현재 화면 재확인 대기 · 이동·입장·AUTO를 누르지 않고 관찰합니다.')
                    self.job = self.owner.after(3000, self.tick)
                    return
                if max(notice(image), shop(image), warehouse(image), quest_travel(image)) >= .70:
                    raise RuntimeError('열린 상점·창고·알림을 닫고 복귀 화면에서 실행하세요.')
                title, cost = special_entry_dialog(image)
                buy, buy_cost = purchase_dialog(image)
                if (title >= .86 and cost >= .80) or (buy >= .88 and buy_cost >= .80):
                    raise RuntimeError('확인창이 열려 있어 시작하지 않습니다.')
            self.phase = 'scan'
            self.log('현재 화면 확인 → 메뉴·특수지역 → 다섯 지역 현재 시간 재검사 → 첫 남은 지역 입장·AUTO')
            self.owner.special_runner.start(chained=True)
        except Exception as exc:
            self.fail(str(exc))

    def wait_for_return(self, expected):
        self.phase = 'observe'
        self.hits = 0
        self.menu_hits = 0
        self.paused = False
        self.required_expired = expected[0]
        self.last_trace = 0
        self.saved_state = None
        self.deadline = time.monotonic()+70*60
        self.log(f'{expected[1]} {expected[2]} 자동 전투 확인 · 이용시간 표시가 사라진 뒤 복귀 화면을 검사합니다.')
        self.job = self.owner.after(3000, self.tick)

    def fail(self, message):
        self.stop()
        self.log(message)

    def inspect(self):
        self.phase = 'scan'
        self.log('필드 화면·특수지역 시간 표시 없음 3회 확인 → 이전 지역의 만료 여부와 다음 지역을 검사합니다.')
        self.owner.special_runner.start(chained=True)

    def all_expired(self, image):
        self.save(image, 'all_expired_general_pending')
        self.stop()
        self.owner.tree.set(self.owner.rows[-1], 'state', '일반 이동 준비')
        self.log('특수지역 5곳 만료 확인 → 일반 사냥터 이동·AUTO 연결')
        self.owner.general_runner.start(chained=True)

    def tick(self):
        self.job = None
        if not self.active:
            return
        if self.handle != self.owner.window_link.hwnd:
            self.fail('연결 창이 바뀌어 이어가기를 중지했습니다.')
            return
        if time.monotonic() > self.deadline:
            self.fail('70분 내 종료·복귀를 확인하지 못해 중지했습니다. 시간만으로 완료 처리하지 않습니다.')
            return
        try:
            check_game_view(self.handle)
        except RuntimeError as exc:
            self.hits = 0
            self.menu_hits = 0
            if not self.paused:
                self.log(f'화면 관찰 대기 · {exc} · 조건이 해소되면 다시 관찰합니다.')
                self.paused = True
            self.job = self.owner.after(3000, self.tick)
            return
        try:
            if self.paused:
                self.log('게임 화면 관찰 재개')
                self.paused = False
            image = from_capture(capture(self.handle))
            screen = special_screen(image)
            self.menu_hits = self.menu_hits+1 if screen >= .85 else 0
            if self.menu_hits:
                self.hits = 0
                if self.menu_hits >= 2:
                    self.log('이미 열린 특수지역 화면 2회 확인 → 현재 화면에서 만료·남은 시간 검사를 재개합니다.')
                    self.inspect()
                    return
                self.job = self.owner.after(3000, self.tick)
                return
            field = auto_control(image)[0]
            timer = special_hud_timer(image)
            blocked = max(screen, notice(image), shop(image),
                          warehouse(image), quest_travel(image)) >= .70
            entry, entry_cost = special_entry_dialog(image)
            buy, buy_cost = purchase_dialog(image)
            blocked = blocked or (entry >= .86 and entry_cost >= .80) or (buy >= .88 and buy_cost >= .80)
            returned = field >= .78 and timer < .60 and not blocked
            self.hits = self.hits+1 if returned else 0
            state = '복귀 후보' if returned else '특수지역 시간 표시 있음' if timer >= .78 else '화면 확인 대기'
            if time.monotonic()-self.last_trace >= 15:
                self.log(f'{state} · 필드 {field:.3f} / 시간표시 {timer:.3f} / 가림창 {blocked} / 연속 {self.hits}/3')
                self.last_trace = time.monotonic()
            if state != self.saved_state:
                self.save(image, 'observe')
                self.saved_state = state
            if self.hits >= 3:
                self.inspect()
                return
            self.job = self.owner.after(3000, self.tick)
        except Exception as exc:
            self.fail(str(exc))
