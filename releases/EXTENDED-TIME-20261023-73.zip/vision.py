"""Reference-image matching. Scores describe similarity, not semantic certainty."""
from pathlib import Path
from io import BytesIO
import numpy as np
from PIL import Image

ASSETS = Path(__file__).resolve().parent / 'assets'


def normalized(image):
    return image.convert('RGB').resize((800, 600))


def from_capture(data):
    return normalized(Image.open(BytesIO(data)))


def _sums(a, h, w):
    integral = np.pad(a, ((1, 0), (1, 0))).cumsum(0).cumsum(1)
    return integral[h:, w:] - integral[:-h, w:] - integral[h:, :-w] + integral[:-h, :-w]


def locate(image, name, roi):
    left, top, right, bottom = roi
    source = np.asarray(image.convert('L'), dtype=np.float64)[top:bottom, left:right]
    with Image.open(ASSETS / (name + '.png')) as template_image:
        template = np.asarray(template_image.convert('L'), dtype=np.float64)
    h, w = template.shape
    H, W = source.shape
    if H < h or W < w:
        raise ValueError('Search area smaller than template')
    template = template - template.mean()
    shape = (1 << (H+h-2).bit_length(), 1 << (W+w-2).bit_length())
    convolution = np.fft.irfft2(np.fft.rfft2(source, shape) *
                               np.fft.rfft2(template[::-1, ::-1], shape), shape)
    numerator = convolution[h-1:H, w-1:W]
    sums = _sums(source, h, w)
    energy = np.maximum(_sums(source*source, h, w) - sums*sums/(h*w), 0)
    denominator = np.sqrt(energy * np.sum(template*template))
    scores = np.divide(numerator, denominator, out=np.zeros_like(numerator), where=denominator > 1)
    y, x = np.unravel_index(np.argmax(scores), scores.shape)
    return float(scores[y, x]), left+int(x)+w/2, top+int(y)+h/2


def npc(image):
    return max((locate(image, name, (0, 100, 760, 520)) for name in ('npc_a', 'npc_b')),
               key=lambda match: match[0])


def white_text(image):
    rgb = np.asarray(image.convert('RGB'), dtype=np.float64)
    return ((rgb.min(axis=2) >= 150) &
            ((rgb.max(axis=2)-rgb.min(axis=2)) <= 65)).astype(np.float64)


def dilate(mask):
    padded = np.pad(mask, ((1, 1), (1, 1)))
    h, w = mask.shape
    return np.maximum.reduce([padded[y:y+h, x:x+w]
                              for y in range(3) for x in range(3)])


def locate_text(image, name, roi, mask_function=white_text):
    """Dice similarity of light neutral glyphs; ignore changing map terrain."""
    left, top, right, bottom = roi
    source = mask_function(image)[top:bottom, left:right]
    with Image.open(ASSETS / (name + '.png')) as reference:
        template = mask_function(reference)
    h, w = template.shape
    H, W = source.shape
    count = template.sum()
    if count < 8:
        raise ValueError('Reference has too few text pixels')
    shape = (1 << (H+h-2).bit_length(), 1 << (W+w-2).bit_length())
    overlap = np.fft.irfft2(np.fft.rfft2(source, shape) *
                           np.fft.rfft2(template[::-1, ::-1], shape), shape)[h-1:H, w-1:W]
    local_count = _sums(source, h, w)
    exact = 2*np.maximum(overlap, 0)/(count+local_count)
    # One-pixel anti-aliasing tolerance, balanced against exact glyph overlap.
    recall_overlap = np.fft.irfft2(np.fft.rfft2(dilate(source), shape) *
                                  np.fft.rfft2(template[::-1, ::-1], shape), shape)[h-1:H, w-1:W]
    precision_overlap = np.fft.irfft2(np.fft.rfft2(source, shape) *
                                     np.fft.rfft2(dilate(template)[::-1, ::-1], shape), shape)[h-1:H, w-1:W]
    recall = np.clip(recall_overlap/count, 0, 1)
    precision = np.divide(precision_overlap, local_count,
                          out=np.zeros_like(local_count), where=local_count > 0)
    precision = np.clip(precision, 0, 1)
    tolerant = np.divide(2*precision*recall, precision+recall,
                         out=np.zeros_like(recall), where=(precision+recall) > 0)
    scores = .5*exact + .5*tolerant
    y, x = np.unravel_index(np.argmax(scores), scores.shape)
    return float(scores[y, x]), left+int(x)+w/2, top+int(y)+h/2


def town(image):
    return max(locate(image,'town_label_58',(700,75,800,115))[0],
               locate(image,'town_label_right_58',(700,75,800,115))[0],
               locate(image,'town_native_41',(650,55,800,120))[0],
               max(locate_text(image, name, (650, 55, 800, 120))[0]
               for name in ('town', 'town_b', 'town_raw', 'town_raw_1', 'town_raw_2')))


def town_header(image):
    return max(locate(image, name, (625, 0, 740, 45))[0]
               for name in ('town_header', 'town_header_a', 'town_header_b', 'town_header_c'))


def warehouse(image):
    return locate(image, 'warehouse', (690, 0, 790, 55))[0]


def deposit_dialog(image):
    title_score = locate(image, 'deposit_title', (270, 155, 540, 260))[0]
    question_score = locate(image, 'deposit_question', (250, 260, 570, 340))[0]
    return title_score, question_score


def no_store_items(image):
    title_score = locate(image, 'notice_title', (280, 155, 530, 260))[0]
    body_score = locate(image, 'no_store_items', (240, 250, 580, 350))[0]
    return title_score, body_score


def jumo(image):
    return max((locate(image, name, (0, 30, 760, 500)) for name in ('jumo_a', 'jumo_b')),
               key=lambda match: match[0])


def shop(image):
    return locate(image, 'shop_title', (620, 0, 790, 60))[0]


def quest_travel(image):
    return locate(image, 'quest_travel', (180, 155, 620, 265))[0]


def jumo_approach(x, y):
    """Bring NPC body clear of fixed minimap/quest controls before clicking."""
    if x > 500:
        return 0x44, '오른쪽(D)'
    if x < 170:
        return 0x41, '왼쪽(A)'
    if y < 120:
        return 0x57, '위쪽(W)'
    if y > 460:
        return 0x53, '아래쪽(S)'
    return None


def purchase_dialog(image):
    return (max(locate(image, name, (240, 155, 560, 260))[0]
                for name in ('purchase_title', 'purchase_title_native')),
            max(locate(image, name, (260, 250, 440, 330))[0]
                for name in ('purchase_cost_label', 'purchase_cost_native')))


def notice(image):
    return locate(image, 'notice_title', (280, 155, 530, 260))[0]


def no_buy_items(image):
    return locate_text(image, 'no_buy_items', (260, 260, 550, 335))[0]


def special_screen(image):
    return locate(image, 'special_title', (650, 0, 790, 50))[0]


def special_icon(image):
    return locate(image, 'special_icon', (735, 90, 800, 160))


def bag_panel(image):
    return min(locate(image,'bag_tabs',(565,0,790,40))[0],
               locate(image,'bag_delete',(570,550,665,600))[0],
               locate(image,'bag_sort',(725,550,800,600))[0])


def main_menu_button(image):
    return locate(image,'main_menu_button',(745,535,800,595))


def region_card(image, key):
    score, x, y = locate(image, 'region_'+key, (8, 90, 215, 590))
    return score, round(x-68), round(y-38)


def selected_card(image, left, top):
    rgb = np.asarray(image.convert('RGB'), dtype=np.float64)
    bright = (rgb.min(axis=2) > 110) & ((rgb.max(axis=2)-rgb.min(axis=2)) < 100)
    if not (3 <= left <= 30 and 90 <= top <= 525):
        return False
    upper = bright[top-3:top+6, left+5:left+190].mean(axis=1).max()
    side = bright[top+5:top+68, left-3:left+6].mean(axis=0).max()
    right = bright[top+5:top+68, left+187:left+202].mean(axis=0).max()
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gold = (r > 95) & (g > 65) & (r > b*1.15) & (g > b*1.1)
    gold_side = gold[top+5:top+68, max(left-6,0):left+7].mean(axis=0).max()
    gold_top = gold[top-5:top+7, left+5:left+190].mean(axis=1).max()
    return bool((side > .50 and (upper > .50 or right > .50)) or
                (gold_side > .50 and gold_top > .50))


def red_text(image):
    rgb = np.asarray(image.convert('RGB'), dtype=np.float64)
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    return ((r > 85) & (r > g*1.65) & (r > b*1.45)).astype(np.float64)


def special_card_expired(image, left, top):
    return locate_text(image, 'expired_card',
                       (left+110, top+48, min(left+199, 218), min(top+79, 600)), red_text)[0]


def special_expired(image, left, top):
    card = special_card_expired(image, left, top)
    # Shorter descriptions (tomb) place the time row at y=193, while
    # other regions place it at y=207/220. Include the entire 22px glyph
    # template at each row, keeping the search inside the detail panel.
    detail = locate_text(image, 'expired_detail', (270, 170, 410, 250), red_text)[0]
    return card, detail


def special_remaining(image):
    minute, x, y = locate(image, 'timer_minute', (290, 185, 420, 235))
    second, sx, sy = locate(image, 'timer_second',
                                  (int(x+6), max(180,int(y-10)), min(440,int(x+50)), min(245,int(y+10))))
    valid = minute >= .78 and second >= .78 and abs(sy-y) <= 4 and sx > x+5
    if valid:
        return True, minute, second
    # Hours+minutes display (e.g. 04시간00분): match units only.
    # The digit value is deliberately not read; extra tickets may give 2-6+ hours.
    # Expired-region red marks remain independently required by callers.
    # Description length moves the time row: tomb y193, middle regions
    # y207, soul/city y220. Freshly reset hours must work on every row.
    # The translucent text inherits the selected region's terrain. Keep the
    # native pair and a verified landfill pair rather than lowering thresholds.
    for suffix in ('native', 'landfill'):
        hour, hx, hy = locate(image, 'timer_hour_'+suffix, (290, 170, 380, 240))
        if hour >= .88:
            native_minute, mx, my = locate(image, 'timer_minute_'+suffix,
                                          (int(hx+12), int(hy-8), min(410,int(hx+40)), int(hy+8)))
            if native_minute >= .88 and 14 <= mx-hx <= 32 and abs(my-hy) <= 2:
                return True, hour, native_minute
    return False, minute, second


def special_in_use(image,left,top):
    # A stale post-return list can still show gray '이용중' in both places.
    # This requests a refresh, never proves expiry or authorizes an entry.
    card=locate(image,'in_use_card',(left+140,top+48,min(left+199,218),min(top+79,600)))[0]
    detail=locate(image,'in_use_detail',(290,170,380,245))[0]
    return card>=.92 and detail>=.92


def special_floor_selected(image, floor):
    rgb = np.asarray(image.convert('RGB'), dtype=np.float64)
    yy, xx = np.mgrid[-25:26, -25:26]
    ring = (np.abs(xx)+np.abs(yy) >= 18) & (np.abs(xx)+np.abs(yy) <= 27)
    scores = {}
    for level, y in {1:484, 2:421, 3:358, 4:294}.items():
        patch = rgb[y-25:y+26, 656:707]
        r, g, b = patch[:,:,0], patch[:,:,1], patch[:,:,2]
        gold = (r > 70) & (g > 55) & (b < g*.8) & (r >= g)
        scores[level] = float(gold[ring].mean())
    target = scores[int(floor)]
    other = max(value for level,value in scores.items() if level != int(floor))
    return target >= .18 and target-other >= .12


def special_entry_dialog(image):
    return (max(locate(image, name, (240, 155, 560, 260))[0] for name in ('entry_title','entry_title_unscaled')),
            max(locate(image, name, (270, 250, 440, 330))[0] for name in ('entry_cost','entry_cost_unscaled')))


def auto_control(image):
    # Key badges are opaque, unlike the AUTO label's changing world background.
    u_score, ux, uy = locate(image, 'hud_u_key', (755, 124, 800, 153))
    p_score, px, py = locate(image, 'hud_p_key', (725, 124, 770, 153))
    if u_score >= .82 and p_score >= .82 and 27 <= ux-px <= 36 and abs(uy-py) <= 2:
        return (u_score+p_score)/2, ux, uy-14
    reference = max((locate(image, name, (740, 95, 800, 150))
                     for name in ('auto_control','auto_unscaled','auto_field','auto_field_b')), key=lambda result:result[0])
    return reference if reference[0] >= .90 else (0.0, reference[1], reference[2])


def yellow_text(image):
    rgb = np.asarray(image.convert('RGB'), dtype=np.float64)
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    return ((r > 150) & (g > 85) & (b < g*.75)).astype(np.float64)


def combat_active(image):
    return max(locate_text(image, name, (180, 350, 620, 500), yellow_text)[0]
               for name in ('combat_active','combat_unscaled','combat_native_42'))


def auto_mode(image):
    # Match the opaque AUTO label separately from the surrounding world and
    # key badge. The ON glow has both bright and dim animation frames.
    on=max(locate(image,'auto_on_42',(745,100,800,145))[0],
           locate(image,'auto_on_label',(750,112,795,135))[0],
           locate(image,'auto_on_label_right',(750,112,795,135))[0])
    off=max(locate(image,'auto_off_42',(745,100,800,145))[0],
            locate(image,'auto_off_label',(750,112,795,135))[0])
    if on>=.90 and on-off>=.08:return 'on'
    if off>=.90 and off-on>=.08:return 'off'
    return 'unknown'


def timer_text(image):
    rgb = np.asarray(image.convert('RGB'), dtype=np.float64)
    return ((rgb.min(axis=2) >= 110) &
            ((rgb.max(axis=2)-rgb.min(axis=2)) <= 65)).astype(np.float64)


def special_hud_timer(image):
    return locate_text(image, 'special_timer_label', (580, 72, 645, 103), timer_text)[0]


def world_map(image):
    return locate(image, 'world_map_title', (680, 0, 790, 45))[0]


def world_destination(image, key):
    return locate(image, 'world_'+key, (140, 160, 550, 430))


def general_row(image, key):
    return locate(image, 'general_row_'+key, (45, 90, 175, 555))


def general_row_selected(image, y):
    rgb = np.asarray(image.convert('RGB'), dtype=np.float64)
    bright = (rgb.min(axis=2) > 110) & ((rgb.max(axis=2)-rgb.min(axis=2)) < 100)
    y = round(y)
    side = bright[y-12:y+13, 13:26].mean(axis=0).max()
    return bool(side > .70)


def general_location(image, key):
    score = locate_text(image, 'general_name_'+key, (640, 65, 800, 115))[0]
    score=max(score,locate_text(image,'general_location_'+key+'_native',(640,65,800,115))[0])
    score=max(score,locate(image,'general_name_'+key,(640,65,800,115))[0],
              locate(image,'general_location_'+key+'_native',(640,65,800,115))[0])
    if key == 'ship':
        score = max(score, locate_text(image, 'general_location_ship', (640, 65, 800, 115))[0])
    return score


def npc_visual(image, kind):
    """Paired overhead service marker and NPC sprite; text may be occluded."""
    prefix = 'jumo' if kind == 'jumo' else 'grandma'
    marker, mx, my = locate(image, prefix+'_marker', (0, 30, 760, 470))
    if marker < .85:
        return 0.0, mx, my+88, marker
    roi = (max(0,int(mx-40)), max(70,int(my+35)), min(800,int(mx+40)), min(540,int(my+140)))
    if roi[3]-roi[1] < 80 or roi[2]-roi[0] < 42:
        return 0.0, mx, my+88, marker
    names = ('jumo_body',) if kind == 'jumo' else ('grandma_body_a','grandma_body_b')
    body, bx, by = max((locate(image,name,roi) for name in names),key=lambda item:item[0])
    paired = body >= .82 and abs(bx-mx) <= 14 and 60 <= by-my <= 115
    if paired:
        return min(marker,body), bx, by, marker
    return 0.0, mx, my+88, marker
