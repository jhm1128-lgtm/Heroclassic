from runner_timer import runner_after, invalidate
from attendance import dismiss_attendance, reset_attendance
"""One event entry, AUTO, observation and scheduled return to general hunt."""
import time
import numpy as np
from datetime import datetime
from pathlib import Path
from window_link import capture
from game_actions import check_game_view,click_client_point,scroll_region_list
from buy_runner import wallet,wallet_similarity
from special_runner import full_card
from vision import (from_capture,special_screen,special_icon,world_map,selected_card,
    auto_control,combat_active,notice,shop,warehouse,quest_travel,special_hud_timer,town,general_location)
from event_vision import event_card,tab_score,floor_one,event_dialog
from event_schedule import events_for

class EventRunner:
    def __init__(self,owner):
        self.owner=owner;self.active=False;self.job=None;self.phase='idle'

    def stop(self):
        invalidate(self)
        self.active=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None

    def log(self,text):
        self.owner.town_log('[이벤트 진행] '+text)
        try:
            path=Path(__file__).resolve().parent/'diagnostics';path.mkdir(exist_ok=True)
            with (path/'event_entry.log').open('a',encoding='utf-8') as f:
                f.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} 창{getattr(self,"handle",0)} {self.phase} {text}\n')
        except OSError:pass

    def save(self,image,label):
        try:
            path=Path(__file__).resolve().parent/'diagnostics';path.mkdir(exist_ok=True)
            image.save(path/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_event_{self.event.key}_{label}.png')
        except OSError:pass

    def start(self,event,deadline):
        self.stop();self.event=event;self.end=deadline
        current=self.owner.event_scheduler.now()
        if (not self.owner.daily_scheduler.active or current>=deadline or
                event not in events_for(self.owner.right,current.date()) or
                not event.start<=current.time()<event.end):
            self.log('예약이 꺼졌거나 이벤트 종료 시각이 지나 입장하지 않습니다.');return
        self.handle=self.owner.window_link.hwnd
        self.phase='origin';reset_attendance(self)
        self.active=True;self.hits=0;self.touched=False
        self.origin_closed=False;self.origin_menu_closed=False
        self.clicked_icon=False;self.menu_opened=False;self.map_closed=False;self.tab_clicked=False
        self.scrolled=0;self.seen_timer=False;self.paused=False;self.entry_clicked=False;self.confirmed=False
        self.seen_combat=False
        self.deadline=time.monotonic()+180;self.limit=time.monotonic()+25
        self.owner.event_scheduler.entering(event,deadline)
        self.log(event.name+' 1층 · 일반 사냥에서 이벤트 메뉴 이동 시작')
        self.job=runner_after(self,1000,self.tick)

    def later(self):self.job=runner_after(self,900 if self.phase!='observe' else 3000,self.tick)
    def stable(self,valid):
        self.hits=self.hits+1 if valid else 0
        return self.hits>=2
    def change(self,phase,limit=20):
        self.phase=phase;self.hits=0;self.limit=time.monotonic()+limit

    def fail(self,text,image=None):
        if image is not None:self.save(image,'error')
        self.stop();self.log(text)
        self.owner.event_scheduler.entry_failed(self.event,self.end,text,restore=self.touched)

    def tick(self):
        self.job=None
        if not self.active:return
        image=None
        try:
            if self.handle!=self.owner.window_link.hwnd:raise RuntimeError('연결된 게임 창 변경')
            if not self.owner.event_scheduler.active:self.stop();return
            if self.owner.event_scheduler.now()>=self.end:
                self.owner.event_scheduler.request_return(self.event,self.end,'예약 종료 시각');self.stop();return
            try:check_game_view(self.handle)
            except RuntimeError:
                if self.phase!='observe':raise
                self.hits=0;self.paused=True;self.later();return
            image=from_capture(capture(self.handle))
            if dismiss_attendance(self,image):self.later();return
            now=time.monotonic()
            if self.phase!='observe' and (now>self.deadline or now>self.limit):
                raise RuntimeError(self.phase+' 확인 시간 초과 · 입장·AUTO를 반복하지 않습니다.')
            if self.phase=='observe':
                timer=special_hud_timer(image)
                self.seen_timer=self.seen_timer or timer>=.78
                field=auto_control(image)[0]>=.78
                blocked=max(notice(image),shop(image),warehouse(image),quest_travel(image),special_screen(image),world_map(image))>=.70
                back=(town(image)>=.78 or general_location(image,self.owner.general_key)>=.78 or (self.seen_timer and timer<.60))
                if self.stable(field and back and not blocked) and now-self.entered_at>=10:
                    self.save(image,'early_return')
                    self.owner.event_scheduler.request_return(self.event,self.end,'실제 이벤트 종료·필드 복귀 확인')
                    self.stop();return
                self.later();return
            if max(notice(image),shop(image),warehouse(image),quest_travel(image))>=.82:
                raise RuntimeError('알림·상점·창고 등 다른 화면이 있어 입장 중지')
            screen=special_screen(image)
            if self.phase=='origin':
                if screen>=.85 or world_map(image)>=.85:
                    self.hits=0
                    if not self.origin_closed:
                        click_client_point(self.handle,774/800,20/600);self.origin_closed=True
                elif special_icon(image)[0]>=.82:
                    self.hits=0
                    if not self.origin_menu_closed:
                        click_client_point(self.handle,.976,.963);self.origin_menu_closed=True
                else:
                    if special_hud_timer(image)>=.60:
                        raise RuntimeError('이미 다른 시간제 지역 사냥 중 · 중복 입장하지 않습니다.')
                    known=max(town(image),general_location(image,self.owner.general_key))>=.78
                    if self.stable(known and auto_control(image)[0]>=.78):
                        self.log('일반 사냥터 또는 한밭마을 출발 화면 연속 확인')
                        self.change('open')
            elif self.phase=='open':
                if screen>=.85:
                    if self.stable(True):self.touched=True;self.change('tab')
                elif world_map(image)>=.85:
                    if not self.map_closed:
                        click_client_point(self.handle,774/800,20/600);self.map_closed=True;self.touched=True
                else:
                    self.hits=0
                    if special_hud_timer(image)>=.60:
                        raise RuntimeError('이미 다른 시간제 지역 사냥 중 · 중복 입장하지 않습니다.')
                    score,x,y=special_icon(image)
                    if score>=.82 and not self.clicked_icon:
                        click_client_point(self.handle,x/800,y/600);self.clicked_icon=True;self.touched=True
                    elif not self.menu_opened and not self.clicked_icon and auto_control(image)[0]>=.78:
                        click_client_point(self.handle,.976,.963);self.menu_opened=True;self.touched=True
            elif screen<.85 and self.phase not in ('arrival','combat'):
                raise RuntimeError('특수지역 메뉴가 확인되지 않습니다.')
            elif self.phase=='tab':
                if self.stable(tab_score(image,self.event.tab)>=.85):self.change('find',25)
                elif not self.tab_clicked and tab_score(image,self.event.tab)<.85:
                    click_client_point(self.handle,(65 if self.event.tab=='special' else 266)/800,65/600)
                    self.tab_clicked=True
            elif self.phase=='find':
                score,left,top=event_card(image,self.event.key)
                if score>=.85 and full_card(left,top):
                    click_client_point(self.handle,(left+95)/800,(top+38)/600)
                    self.log(self.event.name+' 이름·카드 확인 → 선택')
                    self.change('floor')
                elif self.scrolled<10:
                    scroll_region_list(self.handle,240 if self.scrolled<2 else -240);self.scrolled+=1
                else:raise RuntimeError(self.event.name+' 전체 카드를 찾지 못했습니다.')
            elif self.phase in ('floor','ready','confirm'):
                score,left,top=event_card(image,self.event.key)
                selected=(score>=.85 and full_card(left,top) and selected_card(image,left,top)
                          and tab_score(image,self.event.tab)>=.85)
                if self.phase=='confirm':
                    # The confirmation dialog can cover the end of a card's
                    # name. Preserve its verified, unobscured artwork instead.
                    top=self.selected_top
                    patch=np.asarray(image.convert('L'),dtype=float)[top+10:top+65,25:140]
                    selected=(selected_card(image,17,top) and tab_score(image,self.event.tab)>=.85
                              and wallet_similarity(self.selection_patch,patch)>=.90)
                if self.phase=='floor':
                    if self.stable(selected):
                        click_client_point(self.handle,681/800,484/600);self.change('ready')
                else:
                    gold,x,y=floor_one(image,self.event.tab)
                    valid=selected and gold>=.82
                    dialog=event_dialog(image)
                    if self.phase=='ready' and self.stable(valid and not dialog):
                        self.save(image,'selected_1f')
                        self.selected_top=top
                        self.selection_patch=np.asarray(image.convert('L'),dtype=float)[top+10:top+65,25:140].copy()
                        click_client_point(self.handle,.85,.95);self.entry_clicked=True
                        self.change('confirm',12)
                        self.log(self.event.name+' 1층 연속 확인 → 입장 1회')
                    elif self.phase=='confirm' and self.stable(valid and dialog):
                        self.before_wallet=wallet(image);self.save(image,'before_confirm')
                        click_client_point(self.handle,.622,.643);self.confirmed=True
                        self.change('arrival',30);self.log('입장 질문·지불 엽전·선택 지역 1층 확인 → 확인 1회')
            elif self.phase=='arrival':
                auto,x,y=auto_control(image)
                valid=screen<.70 and not event_dialog(image) and auto>=.78 and wallet_similarity(self.before_wallet,wallet(image))<.98
                self.seen_combat=self.seen_combat or (valid and combat_active(image)>=.80)
                if self.stable(valid):
                    if not self.seen_combat:
                        click_client_point(self.handle,x/800,y/600);self.log('입장 후 필드 확인 → AUTO 1회')
                    self.change('combat',15)
            elif self.phase=='combat':
                if self.stable(screen<.70 and auto_control(image)[0]>=.78 and combat_active(image)>=.80):
                    self.save(image,'combat');self.phase='observe';self.hits=0;self.entered_at=now
                    self.log(self.event.name+' 1층 자동 전투 확인 → 종료 후 '+self.owner.destination+' 복귀')
            self.later()
        except Exception as exc:self.fail(str(exc),image)
