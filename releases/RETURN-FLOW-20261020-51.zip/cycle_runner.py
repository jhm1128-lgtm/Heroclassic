from runner_timer import runner_after, invalidate
from attendance import dismiss_attendance, reset_attendance
"""Observe a current special hunt, then inspect remaining daily regions."""
import time
from passive_observer import observe_return
from runner_focus import ensure_view
from datetime import datetime
from pathlib import Path
from window_link import capture
from game_actions import check_game_view
from vision import (from_capture, auto_control, special_screen, notice,
                    special_hud_timer, shop, warehouse, quest_travel,
                    purchase_dialog, special_entry_dialog, special_icon,auto_mode)


class CycleRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        invalidate(self)
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, message):
        self.owner.town_log('[특수지역 이어가기] '+message)
        folder = Path(__file__).resolve().parent/'diagnostics'
        try:
            folder.mkdir(exist_ok=True)
            with (folder/'special_cycle.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} {message}\n')
        except OSError:
            pass

    def save(self, image, label):
        # Observation begins before SpecialRunner has been started.
        folder = Path(__file__).resolve().parent/'diagnostics'
        try:
            folder.mkdir(exist_ok=True)
            image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_cycle_{label}.png')
        except OSError as exc:
            self.log(f'진단 화면 저장 실패 · {exc}')

    def start_remaining(self, chained=False):
        self.stop()
        """Reinspect current game data from town; no remembered expiry required."""
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        reset_attendance(self)
        self.active = True
        self.retry_count = 0
        self.general_pending = False
        self.phase = 'resume'
        self.required_expired = None
        self.completed_indices=set()
        self.passive_visible=False
        self.passive_seen_timer=False
        self.passive_return_hits=0
        self.hidden_since = None
        self.focus_retry_at = 0
        self.deadline = time.monotonic()+90
        self.log('3초 후 현재 이용시간 재검사 · 한밭마을 또는 열린 특수지역 화면을 활성화하세요. 이전 완료 기록은 사용하지 않습니다.')
        self.job = runner_after(self,3000, self.resume_check)

    def resume_check(self):
        self.job = None
        if not self.active:
            return
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결된 게임 창이 바뀌었습니다.')
            if not ensure_view(self,check_game_view):
                self.job=runner_after(self,3000,self.resume_check)
                return
            image = from_capture(capture(self.handle))
            if dismiss_attendance(self,image):
                self.job=runner_after(self,900,self.resume_check)
                return
            screen = special_screen(image)
            timer = special_hud_timer(image)
            field = auto_control(image)[0]
            menu_open = special_icon(image)[0] >= .82
            self.save(image, 'resume_check')
            self.log(f'재개 화면 점수 · 특수메뉴 {screen:.3f} / 시간표시 {timer:.3f} / 필드 {field:.3f} / 전체메뉴 {menu_open}')
            entry,entry_cost=special_entry_dialog(image)
            buy,buy_cost=purchase_dialog(image)
            if (entry>=.86 and entry_cost>=.80) or (buy>=.88 and buy_cost>=.80):
                self.retry_from_error('확인창 처리 결과 대기 · 결제/입장 확인을 반복하지 않습니다.')
                return
            if screen < .85:
                if timer >= .60 or (field < .78 and not menu_open):
                    attempted=getattr(self.owner,'entry_runner',None)
                    if timer>=.78 and getattr(attempted,'recovery_pending',False) and attempted.expected is not None:
                        self.required_expired=attempted.expected[0]
                        attempted.recovery_pending=False
                    if timer>=.78 and field>=.78 and hasattr(self.owner,'recovery_runner'):
                        self.phase='auto_recovery'
                        def recovered(success):
                            if not self.active:return
                            if success:self.observe_current()
                            else:self.fail('현재 특수지역 AUTO 복구 확인 실패 · 재입장 없음')
                        self.owner.recovery_runner.start(require='special',done=recovered)
                        return
                    self.phase = 'observe'
                    self.hits = 0
                    self.menu_hits = 0
                    self.paused = False
                    self.last_trace = 0
                    self.saved_state = None
                    self.deadline = time.monotonic()+70*60
                    if timer >= .78:
                        self.log('특수지역 시간 표시 확인 · 재입장·AUTO 클릭 없이 종료를 관찰합니다.')
                    else:
                        self.log('현재 화면 재확인 대기 · 이동·입장·AUTO를 누르지 않고 관찰합니다.')
                    self.job = runner_after(self,3000, self.tick)
                    self.ensure_shared_watch()
                    return
                if max(notice(image), shop(image), warehouse(image), quest_travel(image)) >= .70:
                    raise RuntimeError('열린 상점·창고·알림을 닫고 복귀 화면에서 실행하세요.')
                title, cost = special_entry_dialog(image)
                buy, buy_cost = purchase_dialog(image)
                if (title >= .86 and cost >= .80) or (buy >= .88 and buy_cost >= .80):
                    raise RuntimeError('확인창이 열려 있어 시작하지 않습니다.')
            self.phase = 'scan'
            self.log('현재 화면 확인 → 메뉴·특수지역 → 위에서부터 시간 검사 → 첫 남은 지역 즉시 입장·AUTO')
            self.owner.special_runner.start(chained=True)
        except Exception as exc:
            self.fail(str(exc))

    def observe_current(self):
        self.handle=self.owner.window_link.hwnd
        self.phase='observe';self.hits=0;self.menu_hits=0;self.paused=False
        self.hidden_since=None;self.focus_retry_at=0;self.last_trace=0;self.saved_state=None
        self.deadline=time.monotonic()+70*60
        self.log('현재 사냥터 AUTO 확인 → 재입장 없이 종료 관찰 재개')
        self.job=runner_after(self,3000,self.tick)
        self.ensure_shared_watch()

    def ensure_shared_watch(self):
        app=self.owner.winfo_toplevel()
        dual=getattr(app,'dual_runner',None)
        if dual is not None and not dual.active and sum(dual.observing(p) for p in app.profiles)>=2:
            dual.start()

    def wait_for_return(self, expected):
        self.retry_count = 0
        self.phase = 'observe'
        self.hits = 0
        self.menu_hits = 0
        self.paused = False
        self.required_expired = expected[0]
        self.hidden_since = None
        self.focus_retry_at = 0
        self.last_trace = 0
        self.saved_state = None
        self.deadline = time.monotonic()+70*60
        self.log(f'{expected[1]} {expected[2]} 자동 전투 확인 · 이용시간 표시가 사라진 뒤 복귀 화면을 검사합니다.')
        self.job = runner_after(self,3000, self.tick)
        self.ensure_shared_watch()

    def fail(self, message):
        if not any(s in message for s in ('연결','게임 창을 먼저','마우스 버튼을 직접','해제 실패')):
            self.retry_from_error(message)
            return
        self.stop()
        self.log(message)

    def retry_from_error(self,message):
        self.stop()
        self.active=True;self.phase='retry_wait'
        self.retry_count=getattr(self,'retry_count',0)+1
        delay=min(120,30*2**min(self.retry_count-1,2))
        if '이용중 표시 갱신 대기' in message:delay=30
        self.log(f'진행 복구 대기 {delay}초 · '+message+' · 완료로 건너뛰지 않고 현재 화면 재검사')
        required=getattr(self,'required_expired',None)
        handle=self.owner.window_link.hwnd
        def request():
            self.job=None
            if not self.active or self.owner.window_link.hwnd!=handle:
                self.stop();return
            app=self.owner.winfo_toplevel()
            self.phase='observe'
            def begin():
                self.active=True;self.handle=handle;self.required_expired=required
                self.phase='resume';self.hidden_since=None;self.focus_retry_at=0
                self.deadline=time.monotonic()+90
                reset_attendance(self)
                self.job=runner_after(self,1000,self.resume_check)
            app.work_coordinator.submit(app.profiles.index(self.owner),'특수지역 복구 재검사',begin,self.fail,scheduled=True,
                                        priority='이용중 표시 갱신 대기' in message)
        self.job=runner_after(self,delay*1000,request)

    def inspect(self):
        self.phase = 'observe'
        owner=self.owner
        required=self.required_expired
        completed=set(getattr(self,'completed_indices',()))
        final=required==4 and {0,1,2,3}.issubset(completed)
        self.log('조선왕릉 종료 복귀 확인 → 일반사냥 대기 등록' if final else '복귀 확인 → 다음 지역 검사 대기 등록 · 대상 창 활성화 후 진행')
        app=owner.winfo_toplevel()
        def begin():
            self.active=True
            self.handle=owner.window_link.hwnd
            self.required_expired=required
            self.completed_indices=completed
            if final:
                self.log('앞선 네 지역 완료·조선왕릉 종료 복귀 확인 → 목록 재조회 없이 일반사냥')
                self.completed_indices.add(4)
                owner.tree.set(owner.rows[6],'state','완료·복귀 확인')
                self.stop()
                self.general_pending=True
                owner.general_runner.start(chained=True)
            else:
                self.phase='scan'
                owner.special_runner.start(chained=True)
        app.work_coordinator.submit(app.profiles.index(owner),'특수지역 완료 → 일반사냥' if final else '다음 특수지역 검사',begin,self.fail,scheduled=True,priority=True)

    def all_expired(self, image):
        self.save(image, 'all_expired_general_pending')
        self.stop()
        self.general_pending=True
        self.owner.tree.set(self.owner.rows[-1], 'state', '일반 이동 준비')
        self.log('특수지역 5곳 만료 확인 → 일반 사냥터 이동·AUTO 연결')
        self.owner.general_runner.start(chained=True)

    def retry_general(self,message):
        if not getattr(self,'general_pending',False):return
        self.stop()
        self.log('일반사냥 전환 복구 30초 대기 · '+message)
        def request():
            self.job=None
            if not self.general_pending:return
            app=self.owner.winfo_toplevel()
            def begin():
                self.general_pending=True
                self.owner.general_runner.start(chained=True)
            def failed(message):
                if '연결' in message:
                    self.general_pending=False
                    self.log(message)
                else:self.retry_general(message)
            app.work_coordinator.submit(app.profiles.index(self.owner),'일반사냥 전환 복구',
                begin,failed,scheduled=True)
        self.job=runner_after(self,30000,request)

    def tick(self):
        self.job = None
        if not self.active:
            return
        if self.handle != self.owner.window_link.hwnd:
            self.fail('연결 창이 바뀌어 이어가기를 중지했습니다.')
            return
        if self.phase=='observe' and observe_return(self):
            if self.active:self.job=runner_after(self,1500,self.tick)
            return
        try:
            if not ensure_view(self,check_game_view,observing=True):
                self.hits=0
                self.menu_hits=0
                self.job=runner_after(self,3000,self.tick)
                return
        except RuntimeError as exc:
            self.hits = 0
            self.menu_hits = 0
            if not self.paused:
                self.log(f'화면 관찰 대기 · {exc} · 조건이 해소되면 다시 관찰합니다.')
                self.paused = True
            self.job = runner_after(self,3000, self.tick)
            return
        try:
            if time.monotonic() > self.deadline:
                self.fail('70분 내 종료·복귀를 확인하지 못해 중지했습니다. 시간만으로 완료 처리하지 않습니다.')
                return
            if self.paused:
                self.log('게임 화면 관찰 재개')
                self.paused = False
            image = from_capture(capture(self.handle))
            if dismiss_attendance(self,image):
                self.job=runner_after(self,900,self.tick)
                return
            screen = special_screen(image)
            self.menu_hits = self.menu_hits+1 if screen >= .85 else 0
            if self.menu_hits:
                self.hits = 0
                if self.menu_hits >= 2:
                    self.log('이미 열린 특수지역 화면 2회 확인 → 현재 화면에서 만료·남은 시간 검사를 재개합니다.')
                    self.inspect()
                    return
                self.job = runner_after(self,3000, self.tick)
                return
            field = auto_control(image)[0]
            timer = special_hud_timer(image)
            blocked = max(screen, notice(image), shop(image),
                          warehouse(image), quest_travel(image)) >= .70
            entry, entry_cost = special_entry_dialog(image)
            buy, buy_cost = purchase_dialog(image)
            blocked = blocked or (entry >= .86 and entry_cost >= .80) or (buy >= .88 and buy_cost >= .80)
            returned = (field >= .78 or auto_mode(image)=='on') and timer < .60 and not blocked
            self.hits = self.hits+1 if returned else 0
            state = '복귀 후보' if returned else '특수지역 시간 표시 있음' if timer >= .78 else '화면 확인 대기'
            if time.monotonic()-self.last_trace >= 15:
                self.log(f'{state} · 필드 {field:.3f} / 시간표시 {timer:.3f} / 가림창 {blocked} / 연속 {self.hits}/3')
                self.last_trace = time.monotonic()
            if state != self.saved_state:
                self.save(image, 'observe')
                self.saved_state = state
            if self.hits >= 3:
                self.inspect()
                return
            self.job = runner_after(self,3000, self.tick)
        except Exception as exc:
            self.fail(str(exc))
