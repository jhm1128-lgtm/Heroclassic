"""One explicit, foreground-only MAP click for user testing."""
import ctypes as c
import time
from admin_launch import require_admin

def check_game_view(hwnd):
    require_admin()
    if not hwnd or title(hwnd).strip().lower() != 'heroofchosunclassic':
        raise RuntimeError('게임 창을 다시 연결하세요.')
    if u.GetForegroundWindow() != hwnd:
        raise RuntimeError('대상 게임이 활성화되지 않아 중지했습니다.')
    x, y, width, height = bounds(hwnd)
    if not (760 <= width <= 820 and 570 <= height <= 620):
        raise RuntimeError('화면 크기가 검증 범위를 벗어났습니다.')
    for nx in (.03, .25, .5, .75, .97):
        for ny in (.03, .25, .5, .75, .97):
            point = w.POINT(x+round(width*nx), y+round(height*ny))
            if u.GetAncestor(u.WindowFromPoint(point), 2) != hwnd:
                raise RuntimeError('게임 화면이 다른 창에 가려져 중지했습니다.')


def check_observation_area(hwnd):
    """Read only: the top-right HUD may be visible without foreground focus."""
    if not hwnd or title(hwnd).strip().lower()!='heroofchosunclassic':
        raise RuntimeError('게임 창을 다시 연결하세요.')
    x,y,width,height=bounds(hwnd)
    if not (760<=width<=820 and 570<=height<=620):
        raise RuntimeError('관찰 크기 범위 초과')
    for nx in (.726,.80,.90,.998):
        for ny in (.002,.08,.16,.248):
            if u.GetAncestor(u.WindowFromPoint(w.POINT(x+round(width*nx),y+round(height*ny))),2)!=hwnd:
                raise RuntimeError('관찰 영역 가림')
    return x,y,width,height


def step_right(hwnd):
    return step_direction(hwnd, 0x44)


def step_up(hwnd):
    return step_direction(hwnd, 0x57)


def scroll_region_list(hwnd, delta):
    check_game_view(hwnd)
    x, y, width, height = bounds(hwnd)
    if not u.SetCursorPos(x+round(width*.14), y+round(height*.55)):
        raise RuntimeError('특수지역 목록으로 커서를 옮기지 못했습니다.')
    time.sleep(.12)
    check_game_view(hwnd)
    point = w.POINT()
    expected = (x+round(width*.14), y+round(height*.55))
    if not u.GetCursorPos(c.byref(point)) or (point.x, point.y) != expected:
        raise RuntimeError('목록 스크롤 위치가 달라 취소했습니다.')
    event = Input()
    event.payload.mouse.data = delta & 0xffffffff
    event.payload.mouse.flags = 0x0800
    if u.SendInput(1, c.byref(event), c.sizeof(Input)) != 1:
        raise RuntimeError('특수지역 목록 스크롤 전송 실패')


def step_direction(hwnd, virtual_key):
    check_game_view(hwnd)
    scan = u.MapVirtualKeyW(virtual_key, 0)
    if not scan:
        raise RuntimeError('이동 키 코드를 읽지 못했습니다.')
    audit_client_click(hwnd,nx,ny,'send')
    down, up = Input(), Input()
    down.type = up.type = 1
    down.payload.key.scan = up.payload.key.scan = scan
    down.payload.key.flags, up.payload.key.flags = 8, 10
    try:
        if u.SendInput(1, c.byref(down), c.sizeof(Input)) != 1:
            raise RuntimeError('이동 입력이 접수되지 않았습니다.')
        time.sleep(0.16)
    finally:
        if u.SendInput(1, c.byref(up), c.sizeof(Input)) != 1:
            if u.SendInput(1, c.byref(up), c.sizeof(Input)) != 1:
                raise RuntimeError('이동 키 해제 실패 · 사용 중인 이동 키를 직접 눌렀다 떼어주세요.')

def click_client_point(hwnd, nx, ny):
    """One visible, foreground-only click at a proportional client coordinate."""
    require_admin()
    if not hwnd or title(hwnd).strip().lower() != 'heroofchosunclassic':
        raise RuntimeError('게임 창을 다시 연결하세요.')
    if u.GetForegroundWindow() != hwnd:
        raise RuntimeError('선택한 게임 창이 활성화되지 않아 클릭을 취소했습니다.')
    x, y, width, height = bounds(hwnd)
    if not (760 <= width <= 820 and 570 <= height <= 620):
        raise RuntimeError(f'검증 범위를 벗어난 내부 크기 {width}×{height} · 클릭 취소')
    if not (0 < nx < 1 and 0 < ny < 1):
        raise RuntimeError('클릭 좌표가 올바르지 않습니다.')
    target = w.POINT(x + round(width * nx), y + round(height * ny))
    if u.GetAncestor(u.WindowFromPoint(target), 2) != hwnd:
        raise RuntimeError('대상 위치가 다른 창에 가려져 클릭을 취소했습니다.')
    if not u.SetCursorPos(target.x, target.y):
        raise RuntimeError('마우스 이동 실패 · 클릭하지 않았습니다.')
    time.sleep(0.12)
    actual = w.POINT()
    if not u.GetCursorPos(c.byref(actual)) or (actual.x, actual.y) != (target.x, target.y):
        raise RuntimeError('마우스가 목표 위치에 도착하지 않아 클릭을 취소했습니다.')
    if u.GetForegroundWindow() != hwnd or u.GetAncestor(u.WindowFromPoint(actual), 2) != hwnd:
        raise RuntimeError('대상 창이 변경되어 클릭을 취소했습니다.')
    down, up = Input(), Input()
    down.payload.mouse.flags, up.payload.mouse.flags = 2, 4
    try:
        if u.SendInput(1, c.byref(down), c.sizeof(Input)) != 1:
            raise RuntimeError('클릭 누름 전송 실패')
        time.sleep(0.10)
    finally:
        if u.SendInput(1, c.byref(up), c.sizeof(Input)) != 1:
            if u.SendInput(1, c.byref(up), c.sizeof(Input)) != 1:
                raise RuntimeError('클릭 해제 실패 · 왼쪽 버튼을 직접 눌렀다 떼어주세요.')
    audit_client_click(hwnd,nx,ny,'accepted')
    return f'창 ID {hwnd} · 내부 좌표 ({target.x-x}, {target.y-y}) · 클릭 접수'
from ctypes import wintypes as w
from window_link import u, bounds, title

u.MapVirtualKeyW.argtypes = [w.UINT, w.UINT]
u.MapVirtualKeyW.restype = w.UINT
u.SetForegroundWindow.argtypes = [w.HWND]
u.GetForegroundWindow.restype = w.HWND
u.SetCursorPos.argtypes = [c.c_int, c.c_int]
u.SetCursorPos.restype = w.BOOL
u.GetCursorPos.argtypes = [c.POINTER(w.POINT)]
u.GetCursorPos.restype = w.BOOL

class Mouse(c.Structure):
    _fields_ = [('dx',w.LONG),('dy',w.LONG),('data',w.DWORD),('flags',w.DWORD),('time',w.DWORD),('extra',c.c_size_t)]

class Key(c.Structure):
    _fields_ = [('vk',w.WORD),('scan',w.WORD),('flags',w.DWORD),('time',w.DWORD),('extra',c.c_size_t)]

class Hardware(c.Structure):
    _fields_ = [('message',w.DWORD),('low',w.WORD),('high',w.WORD)]

class Payload(c.Union):
    _fields_ = [('mouse',Mouse),('key',Key),('hardware',Hardware)]

class Input(c.Structure):
    _fields_ = [('type',w.DWORD),('payload',Payload)]

u.SendInput.argtypes = [w.UINT,c.POINTER(Input),c.c_int]
u.SendInput.restype = w.UINT
u.WindowFromPoint.argtypes = [w.POINT]
u.WindowFromPoint.restype = w.HWND
u.GetAncestor.argtypes = [w.HWND,w.UINT]
u.GetAncestor.restype = w.HWND

def cursor_diagnostic():
    point = w.POINT()
    c.set_last_error(0)
    if not u.GetCursorPos(c.byref(point)):
        return f'현재 위치 읽기 실패 / 오류 {c.get_last_error()}'
    c.set_last_error(0)
    accepted = bool(u.SetCursorPos(point.x, point.y))
    code = c.get_last_error()
    return f'현재 위치 ({point.x}, {point.y}) / 같은 위치 지정 {"성공" if accepted else "실패"} / 오류 {code}'


def prepare(hwnd):
    if not hwnd:
        raise RuntimeError('게임 창을 먼저 연결하세요.')
    bounds(hwnd)
    if title(hwnd).strip().lower() != 'heroofchosunclassic':
        raise RuntimeError('연결된 창을 다시 확인하세요.')
    u.SetForegroundWindow(hwnd)

def click_map_mouse(hwnd):
    require_admin()
    if u.GetForegroundWindow()!=hwnd:
        raise RuntimeError('게임 창 활성화에 실패했습니다. 클릭하지 않았습니다.')
    x,y,width,height=bounds(hwnd)
    if (width,height)!=(800,600):
        raise RuntimeError(f'현재 내부 크기는 {width}×{height}입니다. 이 시험은 800×600에서만 가능합니다.')
    # Center of minimap, relative to the observed 800x600 client area.
    target_x,target_y=x+715,y+55
    hit=u.WindowFromPoint(w.POINT(target_x,target_y))
    if u.GetAncestor(hit,2)!=hwnd:
        raise RuntimeError('MAP 위치가 다른 창에 가려져 있습니다. 클릭하지 않았습니다.')
    # Standard Windows absolute mouse input, using virtual desktop coordinates.
    origin_x=u.GetSystemMetrics(76)
    origin_y=u.GetSystemMetrics(77)
    desktop_width=u.GetSystemMetrics(78)
    desktop_height=u.GetSystemMetrics(79)
    if desktop_width<=1 or desktop_height<=1:
        raise RuntimeError('화면 크기를 읽을 수 없어 클릭을 취소했습니다.')
    movement=Input()
    movement.payload.mouse.dx=round((target_x-origin_x)*65535/(desktop_width-1))
    movement.payload.mouse.dy=round((target_y-origin_y)*65535/(desktop_height-1))
    movement.payload.mouse.flags=0x0001 | 0x8000 | 0x4000
    c.set_last_error(0)
    if u.SendInput(1,c.byref(movement),c.sizeof(Input))!=1:
        code=c.get_last_error()
        detail=c.FormatError(code).strip() if code else 'Windows가 상세 오류를 제공하지 않았습니다.'
        raise RuntimeError(f'SendInput 이동 실패 · 오류 {code}: {detail} · 클릭하지 않았습니다.')
    actual=w.POINT()
    if not u.GetCursorPos(c.byref(actual)) or (actual.x,actual.y)!=(target_x,target_y):
        raise RuntimeError(f'마우스 이동 확인 실패 · 목표 ({target_x}, {target_y}), 실제 ({actual.x}, {actual.y}) · 클릭하지 않았습니다.')
    if u.GetForegroundWindow()!=hwnd:
        raise RuntimeError('활성 창이 변경되어 클릭을 취소했습니다.')
    events=(Input*2)()
    events[0].payload.mouse.flags=0x0002
    events[1].payload.mouse.flags=0x0004
    sent=u.SendInput(2,events,c.sizeof(Input))
    if sent!=2:
        # Release the mouse if only the first event was accepted.
        release=Input()
        release.payload.mouse.flags=0x0004
        u.SendInput(1,c.byref(release),c.sizeof(Input))
        raise RuntimeError('클릭 입력을 완료하지 못했습니다.')


def click_map(hwnd):
    """Hold the documented M key briefly so frame-based input can observe it."""
    require_admin()
    if not hwnd or title(hwnd).strip().lower() != 'heroofchosunclassic':
        raise RuntimeError('연결된 게임 창을 다시 확인하세요.')
    bounds(hwnd)
    if u.GetForegroundWindow() != hwnd:
        raise RuntimeError('게임 창이 활성화되지 않아 M키를 보내지 않았습니다.')
    scan = u.MapVirtualKeyW(0x4D, 0)
    if not scan:
        raise RuntimeError('M키 스캔코드를 확인할 수 없습니다.')
    down = Input()
    down.type = 1
    down.payload.key.scan = scan
    down.payload.key.flags = 0x0008
    up = Input()
    up.type = 1
    up.payload.key.scan = scan
    up.payload.key.flags = 0x0008 | 0x0002
    c.set_last_error(0)
    accepted = u.SendInput(1, c.byref(down), c.sizeof(Input))
    error = c.get_last_error()
    try:
        if accepted != 1:
            raise RuntimeError(f'M키 누르기 전송 실패 · Windows 오류 {error}')
        time.sleep(0.15)
    finally:
        released = u.SendInput(1, c.byref(up), c.sizeof(Input))
    if released != 1:
        # One explicit retry to avoid leaving the key down.
        released = u.SendInput(1, c.byref(up), c.sizeof(Input))
        if released != 1:
            raise RuntimeError('M키 해제 요청 실패 · 키보드에서 M을 직접 눌렀다 떼어주세요.')


def click_map_at_cursor(hwnd):
    """Click once only when the user has positioned the cursor on the minimap."""
    require_admin()
    if not hwnd or title(hwnd).strip().lower() != 'heroofchosunclassic':
        raise RuntimeError('게임 창을 다시 연결하세요.')
    if u.GetForegroundWindow() != hwnd:
        raise RuntimeError('선택한 게임 창이 활성화되지 않아 클릭을 취소했습니다.')
    x, y, width, height = bounds(hwnd)
    if (width, height) != (800, 600):
        raise RuntimeError('클릭 시험은 내부 화면 800×600에서만 가능합니다.')
    point = w.POINT()
    if not u.GetCursorPos(c.byref(point)):
        raise RuntimeError('마우스 위치를 읽을 수 없습니다.')
    relative_x, relative_y = point.x-x, point.y-y
    if not (650 <= relative_x <= 785 and 10 <= relative_y <= 105):
        raise RuntimeError(f'커서가 미니맵 밖에 있어 클릭 취소 · 창 안 좌표 ({relative_x}, {relative_y})')
    hit = u.WindowFromPoint(point)
    if u.GetAncestor(hit, 2) != hwnd:
        raise RuntimeError('커서 아래에 다른 창이 있어 클릭을 취소했습니다.')
    down = Input()
    down.payload.mouse.flags = 0x0002
    up = Input()
    up.payload.mouse.flags = 0x0004
    c.set_last_error(0)
    accepted = u.SendInput(1, c.byref(down), c.sizeof(Input))
    error = c.get_last_error()
    try:
        if accepted != 1:
            raise RuntimeError(f'마우스 누르기 전송 실패 · Windows 오류 {error}')
        time.sleep(0.10)
    finally:
        released = u.SendInput(1, c.byref(up), c.sizeof(Input))
    if released != 1:
        if u.SendInput(1, c.byref(up), c.sizeof(Input)) != 1:
            raise RuntimeError('마우스 해제 요청 실패 · 왼쪽 버튼을 직접 눌렀다 떼어주세요.')

    return f'관리자 확인 · 창 ID {hwnd} · 내부 좌표 ({relative_x}, {relative_y}) · 클릭 100ms 누름·해제 접수'


def request_game_foreground(hwnd):
    """Request a normal foreground transition; completion is checked later."""
    require_admin()
    if not hwnd or not u.IsWindow(hwnd) or title(hwnd).strip().lower() != 'heroofchosunclassic':
        raise RuntimeError('연결된 게임 창이 없어 다시 연결해야 합니다.')
    if u.IsIconic(hwnd):
        u.ShowWindowAsync(hwnd, 9)
    request_game_foreground.last_method = '일반 전면 전환'
    if u.SetForegroundWindow(hwnd) or u.GetForegroundWindow() == hwnd:
        return True
    if attach_foreground(hwnd):
        request_game_foreground.last_method = '입력 스레드 연결 후 전면 전환 · 연결 해제 완료'
        return True
    # Raise without changing position, size or permanent topmost state.
    # If Windows still denies activation, click only an exposed, verified
    # part of this exact game's caption, never a gameplay coordinate.
    request_game_foreground.last_method = '창 앞으로 이동·제목 표시줄 확인'
    u.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x4000 | 0x0040 | 0x0010 | 0x0002 | 0x0001)
    time.sleep(.05)
    rect=w.RECT()
    try:
        _, client_y, _, _ = bounds(hwnd)
    except RuntimeError:
        return False
    if not u.GetWindowRect(hwnd,c.byref(rect)):
        return False
    caption_height=client_y-rect.top
    width=rect.right-rect.left
    if width < 300 or not 14 <= caption_height <= 80:
        return False
    point=w.POINT(rect.left+min(180,width//3),rect.top+min(16,caption_height//2))
    def exposed():
        return (u.IsWindow(hwnd) and title(hwnd).strip().lower() == 'heroofchosunclassic'
                and u.GetAncestor(u.WindowFromPoint(point),2) == hwnd)
    if not exposed() or not u.SetCursorPos(point.x,point.y):
        return False
    time.sleep(.03)
    actual=w.POINT()
    if (not u.GetCursorPos(c.byref(actual)) or (actual.x,actual.y)!=(point.x,point.y)
            or not exposed()):
        return False
    down,up=Input(),Input()
    down.payload.mouse.flags=0x0002
    up.payload.mouse.flags=0x0004
    try:
        if u.SendInput(1,c.byref(down),c.sizeof(Input)) != 1:
            return False
        time.sleep(.04)
    finally:
        if u.SendInput(1,c.byref(up),c.sizeof(Input)) != 1:
            if u.SendInput(1,c.byref(up),c.sizeof(Input)) != 1:
                raise RuntimeError('창 활성화 클릭 해제 실패 · 마우스 버튼을 직접 눌렀다 떼어주세요.')
    request_game_foreground.last_method = '확인된 게임 제목 표시줄 클릭 1회'
    return u.GetForegroundWindow() == hwnd


def attach_foreground(hwnd):
    """Temporarily share input queues; always detach before returning."""
    if not hasattr(u,'AttachThreadInput'):return False
    current=kernel32.GetCurrentThreadId()
    attached=[]
    try:
        foreground=u.GetForegroundWindow()
        for window in (foreground,hwnd):
            thread=u.GetWindowThreadProcessId(window,None) if window else 0
            if thread and thread!=current and thread not in attached:
                if u.AttachThreadInput(current,thread,True):attached.append(thread)
        if not attached:return False
        u.BringWindowToTop(hwnd)
        u.SetForegroundWindow(hwnd)
        return u.GetForegroundWindow()==hwnd
    finally:
        for thread in reversed(attached):u.AttachThreadInput(current,thread,False)


kernel32=c.WinDLL('kernel32',use_last_error=True)
kernel32.GetCurrentThreadId.restype=w.DWORD
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.GetWindowThreadProcessId.restype=w.DWORD
u.AttachThreadInput.argtypes=[w.DWORD,w.DWORD,w.BOOL]
u.AttachThreadInput.restype=w.BOOL
u.BringWindowToTop.argtypes=[w.HWND]
u.BringWindowToTop.restype=w.BOOL

u.SetForegroundWindow.restype = w.BOOL
u.ShowWindowAsync.argtypes = [w.HWND, c.c_int]
u.ShowWindowAsync.restype = w.BOOL
u.GetWindowRect.argtypes = [w.HWND,c.POINTER(w.RECT)]
u.GetWindowRect.restype = w.BOOL
u.SetWindowPos.argtypes = [w.HWND,w.HWND,c.c_int,c.c_int,c.c_int,c.c_int,w.UINT]
u.SetWindowPos.restype = w.BOOL


def audit_client_click(hwnd,nx,ny,result):
    """Record accepted game inputs locally for future destination tracing."""
    try:
        import sys
        from pathlib import Path
        from datetime import datetime
        caller=sys._getframe(2)
        source=Path(caller.f_code.co_filename).name+':'+caller.f_code.co_name
        phase=getattr(caller.f_locals.get('self'),'phase','')
        del caller
        folder=Path(__file__).resolve().parent/'diagnostics';folder.mkdir(exist_ok=True)
        with (folder/'client_clicks.log').open('a',encoding='utf-8') as stream:
            stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S.%f} hwnd={hwnd} source={source} phase={phase} point=({nx:.5f},{ny:.5f}) {result}\n')
    except Exception:pass
