"""Shared Telegram configuration dialog. Token stays in the local GUI."""
import tkinter as tk
from tkinter import ttk
from telegram_config import save,validate

def open_settings(app):
    old=getattr(app,'telegram_dialog',None)
    if old is not None and old.winfo_exists():old.lift();return
    watch=app.stall_watch;dialog=tk.Toplevel(app);app.telegram_dialog=dialog
    dialog.title('Telegram 알림 설정');dialog.geometry('590x440');dialog.minsize(540,420)
    body=ttk.Frame(dialog,padding=18);body.pack(fill='both',expand=True)
    token=tk.StringVar(value=watch.config['token']);chat=tk.StringVar(value=watch.config['chat']);enabled=tk.BooleanVar(value=watch.config['enabled'])
    ttk.Label(body,text='게임 자동화 · 5분 지연 알림',font=('맑은 고딕',12,'bold')).pack(anchor='w')
    ttk.Label(body,text='확인 가능한 화면의 진행 지연·연결 끊김을 좌우 별도로 감시합니다.').pack(anchor='w',pady=(6,12))
    ttk.Label(body,text='봇 토큰').pack(anchor='w');ttk.Entry(body,textvariable=token,show='*').pack(fill='x',pady=(3,8))
    ttk.Label(body,text='받을 채팅 ID (숫자)').pack(anchor='w');ttk.Entry(body,textvariable=chat).pack(fill='x',pady=(3,8))
    ttk.Label(body,text='다른 창에 가려지거나 비활성화·최소화된 동안에는 경고하지 않습니다.',wraplength=530).pack(anchor='w',pady=(0,4))
    ttk.Checkbutton(body,text='Telegram 경고·경고 해소 알림 사용',variable=enabled).pack(anchor='w',pady=6)
    message=tk.StringVar(value=watch.status)
    ttk.Label(body,textvariable=message,wraplength=530).pack(anchor='w',pady=8)
    def values():return dict(token=token.get().strip(),chat=chat.get().strip(),enabled=enabled.get())
    def save_settings():
        try:
            config=values();save(config);watch.configure(config);message.set('저장 완료 · '+watch.status)
        except (OSError,ValueError):message.set('저장 실패 · 토큰/채팅 ID 형식 또는 파일 저장 권한을 확인하세요.')
    def test():
        try:
            config=values();validate(config['token'],config['chat'])
            accepted=watch.sender.enqueue(config['token'],config['chat'],'【게임 자동화 시험 알림】 Telegram 연결 확인 메시지입니다.')
            message.set('시험 메시지 전송 대기' if accepted else '전송 대기열 오류')
        except ValueError:message.set('토큰과 숫자 채팅 ID 형식을 확인하세요.')
    row=ttk.Frame(body);row.pack(fill='x',pady=8)
    ttk.Button(row,text='저장·적용',command=save_settings).pack(side='left',padx=(0,8))
    ttk.Button(row,text='시험 메시지 보내기',command=test).pack(side='left')
    ttk.Label(body,text='토큰은 이 Windows 사용자 계정으로 암호화해 로컬 저장합니다.\n자동화를 끄면 감시도 멈춥니다. 전송 중인 메시지는 취소되지 않을 수 있습니다.',wraplength=530).pack(anchor='w',pady=8)
    def poll():
        if not dialog.winfo_exists():return
        if getattr(dialog,'last_delivery_status',None)!=watch.status:
            message.set(watch.status);dialog.last_delivery_status=watch.status
        dialog.after(1000,poll)
    dialog.last_delivery_status=watch.status;dialog.after(1000,poll)
