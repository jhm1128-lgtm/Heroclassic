"""Korean-time event windows, independent for each game profile."""
from dataclasses import dataclass
from datetime import datetime, time, timezone, timedelta
from pathlib import Path

KST=timezone(timedelta(hours=9))

@dataclass(frozen=True)
class Event:
    key: str
    name: str
    tab: str
    start: time
    end: time

EVENTS=(Event('abandoned','버려진 동굴','special',time(16),time(17)),
        Event('gadeok','가덕도왜성','special',time(20),time(22)),
        Event('nijo','저주받은 니조성','world',time(19),time(23)))

def events_for(right, day):
    if not right:return EVENTS[:1]
    return (EVENTS[0],EVENTS[2] if day.weekday()==2 else EVENTS[1])

def end_at(event, now):
    return datetime.combine(now.date(),event.end,tzinfo=KST)

class EventScheduler:
    def __init__(self,owner):
        self.owner=owner
        self.active=False
        self.job=None
        self.attempted=set()
        self.returned=set()
        self.session=None
        self.retry_after={}
        self.return_check=None
        self.return_check_queued=False
        self.return_check_at=None

    @staticmethod
    def now():return datetime.now(KST)

    def log(self,text):
        self.owner.town_log('[이벤트 예약] '+text)
        try:
            folder=Path(__file__).resolve().parent/'diagnostics';folder.mkdir(exist_ok=True)
            with (folder/'event_schedule.log').open('a',encoding='utf-8') as f:
                f.write(f'{self.now():%Y-%m-%d %H:%M:%S %z} 창{self.owner.window_link.hwnd} {text}\n')
        except OSError:pass

    def stop(self):
        self.active=False
        self.return_check=None
        self.return_check_queued=False
        app=self.owner.winfo_toplevel()
        if hasattr(app,'work_coordinator') and self.owner in app.profiles:
            app.work_coordinator.cancel_events(app.profiles.index(self.owner))
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None
        if hasattr(self.owner,'event_status'):self.owner.event_status.set('이벤트 예약 꺼짐')

    def arm(self):
        self.stop()
        self.active=True
        self.log('켜짐 · 현재 열려 있는 이벤트도 남은 시간 동안 참여 · 종료 후 일반 사냥 복귀')
        self.job=self.owner.after(1000,self.tick)

    def entering(self,event,deadline):
        self.session=(event,deadline)

    def request_return(self,event,deadline,reason,relocate=False):
        key=(deadline.date(),event.key)
        if key in self.returned:return
        self.returned.add(key)
        if not relocate:
            self.session=None
            self.return_check=(event,deadline)
            self.return_check_at=self.now()
            self.log(event.name+' 게임 자동 복귀 대기 · 이동 없이 일반사냥 AUTO만 확인 · '+reason)
            self.check_return()
            return
        self.log(event.name+' 입장 실패 후 일반 사냥 복구 요청 · '+reason)
        app=self.owner.winfo_toplevel();index=app.profiles.index(self.owner)
        def return_to_general():
            self.owner.cycle_runner.general_pending=True
            self.owner.cycle_runner.general_force_leave=True
            self.owner.general_runner.start(chained=True,force_leave=True)
        app.work_coordinator.submit(index,'이벤트 종료 후 일반 사냥',
            return_to_general,
            scheduled=True,priority=True)
        self.session=None

    def check_return(self):
        if not self.active or self.return_check is None or self.return_check_queued:return
        if self.now()<self.return_check_at:return
        self.return_check_queued=True
        event,deadline=self.return_check
        app=self.owner.winfo_toplevel();index=app.profiles.index(self.owner)
        def finished(success):
            if not self.active or self.return_check!=(event,deadline):return
            self.return_check_queued=False
            if success:
                self.return_check=None
                self.log(event.name+' 자동 복귀 후 일반사냥 AUTO 켜짐 확인 완료 · 추가 이동 없음')
            else:
                self.return_check_at=self.now()+timedelta(seconds=30)
                self.log(event.name+' 일반사냥 자동 복귀·AUTO 확인 대기 · 이동 없이 30초 뒤 재확인')
        def check_auto():
            if not self.active or self.return_check!=(event,deadline):return
            self.owner.recovery_runner.start(require='general',done=finished)
        app.work_coordinator.submit(index,'이벤트 종료 후 AUTO 확인',check_auto,
            lambda text:finished(False),scheduled=True,priority=True)

    def entry_failed(self,event,deadline,text,restore=True,paid=False,entry_clicked=False):
        if not paid and not entry_clicked and self.now()<deadline:
            key=(deadline.date(),event.key)
            self.attempted.discard(key)
            self.retry_after[key]=self.now()+timedelta(seconds=20)
            self.session=None
            self.log(event.name+' 입장 전 확인 실패 · 20초 뒤 자동 재시도 · '+text)
            return
        self.log(event.name+' 입장 중지 · '+text+' · 같은 날 입장을 반복하지 않습니다.')
        if restore:self.request_return(event,deadline,'입장 중지 후 일반 사냥 복구',relocate=True)
        else:self.session=None

    def tick(self):
        self.job=None
        if not self.active:return
        if not self.owner.daily_scheduler.active:self.stop();return
        now=self.now()
        if self.session:
            event,deadline=self.session
            if now>=deadline:self.request_return(event,deadline,'예약 종료 시각 도달')
        self.check_return()
        for event in events_for(self.owner.right,now.date()):
            key=(now.date(),event.key)
            if not event.start<=now.time()<event.end or key in self.attempted:continue
            if now<self.retry_after.get(key,now):continue
            # Daily regions already under observation are completed first.
            if self.owner.cycle_runner.active or self.session:continue
            if self.owner.right and event.key=='abandoned':
                app=self.owner.winfo_toplevel()
                left=app.profiles[0]
                if (left.event_scheduler.active and left.daily_scheduler.active and
                        not left.cycle_runner.active and key not in left.event_scheduler.attempted):
                    continue
            deadline=end_at(event,now)
            self.attempted.add(key)
            app=self.owner.winfo_toplevel();index=app.profiles.index(self.owner)
            self.log(event.name+' 1층 시간 도달 → 일반 사냥에서 이벤트 진입 대기')
            app.work_coordinator.submit(index,'이벤트 입장 '+event.name,
                lambda e=event,d=deadline:self.owner.event_runner.start(e,d),
                lambda text,e=event,d=deadline:self.log(e.name+' 창 전환 실패 · '+text),
                scheduled=True)
        if hasattr(self.owner,'event_status'):
            schedule=' / '.join(e.start.strftime('%H:%M')+'~'+e.end.strftime('%H:%M')+' '+e.name+' 1층'
                                for e in events_for(self.owner.right,now.date()))
            self.owner.event_status.set('이벤트 예약 켜짐 · 오늘 '+schedule)
        self.job=self.owner.after(1000,self.tick)
