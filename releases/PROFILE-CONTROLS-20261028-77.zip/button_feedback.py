"""Persistent button feedback follows actual reservations and queued work."""
def action_key(kind):
    if '전체 순회' in kind:return 'START'
    if '일반사냥' in kind or '일반 사냥' in kind:return '일반사냥'
    if '보급' in kind or '복자할매' in kind:return '상점창고'
    if '특수지역' in kind or '이벤트 입장' in kind:return '특수지역'
    return None


def refresh_buttons(app):
    count=sum(p.daily_scheduler.active for p in app.profiles)
    off=getattr(app,'automation_state','waiting')=='off'
    app.automation_button.configure(text='2분할 자동화 · 켜짐' if count==2 else '2분할 자동화 · 한쪽 켜짐' if count else '2분할 자동화 · 꺼짐' if off else '2분할 자동화 · 대기',
        style='Running.TButton' if count==2 else 'Waiting.TButton' if count else 'Stopped.TButton' if off else 'TButton')
    for index,button in enumerate(getattr(app,'profile_automation_buttons',[])):
        p=app.profiles[index];on=p.daily_scheduler.active
        stopped=getattr(p,'automation_state','waiting')=='off'
        button.configure(text=('왼쪽' if index==0 else '오른쪽')+' 자동화 · '+('켜짐' if on else '꺼짐' if stopped else '대기'),
            style='Running.TButton' if on else 'Stopped.TButton' if stopped else 'TButton')
    q=app.work_coordinator
    for index,p in enumerate(app.profiles):
        current=q.current if q.active and q.current and q.current['index']==index else None
        running=action_key(current['kind']) if current else None
        if running is None:
            if p.general_runner.active:running='일반사냥'
            elif p.supply_runner.active:running='상점창고'
            elif p.cycle_runner.active or p.event_runner.active:running='특수지역'
        waiting={action_key(r['kind']) for r in q.pending if r['index']==index}
        for key,button in p.action_buttons.items():
            state='진행 중' if key==running else '대기' if key in waiting else ''
            button.configure(text=key+(' · '+state if state else ''),
                style='Running.TButton' if key==running else 'Waiting.TButton' if key in waiting else 'TButton')
