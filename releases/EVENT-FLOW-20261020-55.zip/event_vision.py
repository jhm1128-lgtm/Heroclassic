from PIL import Image
import numpy as np
from vision import locate,locate_text,special_floor_selected,ASSETS

def gold_text(image):
    rgb=np.asarray(image.convert('RGB'),dtype=np.float64)
    r,g,b=rgb[:,:,0],rgb[:,:,1],rgb[:,:,2]
    return ((r>35)&(g>25)&(r>b*1.25)&(g>b*1.1)).astype(np.float64)

def event_card(image,key):
    name='event_name_'+key
    match=locate_text(image,name,(85,90,215,590),gold_text)
    photo=locate(image,name,(85,90,215,590))
    score,x,y=max((match,photo),key=lambda m:m[0])
    return score,17,round(y-12)

def tab_score(image,tab):
    roi=(25,45,115,85) if tab=='special' else (225,45,320,85)
    return locate(image,'event_tab_'+tab,roi)[0]

def floor_one(image,tab):
    return locate(image,'event_floor_'+tab,(635,450,730,520))

def event_dialog(image):
    title=locate(image,'event_entry_question',(260,155,590,260))[0]
    cost=max(locate(image,name,(270,250,440,330))[0] for name in ('entry_cost','entry_cost_unscaled'))
    return title>=.86 and cost>=.80
