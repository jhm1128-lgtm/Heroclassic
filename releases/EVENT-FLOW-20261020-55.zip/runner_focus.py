"""Pause an existing state machine while safely restoring its foreground."""
import time
from focus_guard import observation_interval
from work_coordinator import WorkCoordinator


def ensure_view(runner, check, observing=False):
    now=time.monotonic()
    try:
        check(runner.handle)
    except RuntimeError as exc:
        if not any(s in str(exc) for s in ('활성화되지','가려져')):
            raise
        if getattr(runner,'hidden_since',None) is None:
            runner.hidden_since=now
            for key in ('hits','off_hits','combat_hits'):
                if hasattr(runner,key):setattr(runner,key,0)
            if hasattr(runner,'field_since'):runner.field_since=None
            runner.log('게임 화면 가림·비활성화 → 현재 단계 보존 · 창 활성화 대기')
        app=runner.owner.winfo_toplevel()
        if observing:
            interval=observation_interval(app)
            previous=getattr(runner,'quiet_observation_interval',interval)
            if previous!=interval and getattr(runner,'quiet_focus_armed',False):runner.focus_retry_at=now+interval
            runner.quiet_observation_interval=interval
        if observing and not getattr(runner,'quiet_focus_armed',False):
            runner.focus_retry_at=max(getattr(runner,'focus_retry_at',0),now+observation_interval(app))
            runner.quiet_focus_armed=True
        # Two observers use the existing shared turn clock. Critical input
        # never asks another profile to relinquish its in-flight transaction.
        dual=getattr(app,'dual_runner',None)
        if observing and dual is not None and dual.active:
            return False
        focus=app.focus_runner
        queue=app.work_coordinator
        other_busy=any(p is not runner.owner and WorkCoordinator.busy(p) for p in app.profiles)
        current=getattr(queue,'current',None)
        other_work=queue.active and (current is None or app.profiles[current['index']] is not runner.owner)
        if (not focus.active and not other_busy and not other_work
                and (not queue.pending or (not observing and queue.active and not other_work))
                and now>=getattr(runner,'focus_retry_at',0)):
            runner.focus_retry_at=now+(observation_interval(app) if observing else 30)
            focus.start(runner.handle,lambda:None,
                        lambda text:runner.log(text+' · 단계 유지 후 다시 활성화 대기'),runner.log)
        return False
    hidden=getattr(runner,'hidden_since',None)
    if hidden is not None:
        delay=now-hidden
        for key in ('deadline','limit','phase_deadline'):
            if hasattr(runner,key):setattr(runner,key,getattr(runner,key)+delay)
        runner.hidden_since=None
        runner.quiet_focus_armed=False
        runner.log('게임 활성화 확인 → 기존 단계에서 재개 · 입장/AUTO 재클릭 없음')
    return True
