"""Observe only visible idle fields; queue AUTO recovery after reconnect/off."""
from window_link import capture
from game_actions import check_game_view
from work_coordinator import WorkCoordinator
from vision import (from_capture,auto_control,auto_mode,special_hud_timer,general_location,
                    notice,shop,warehouse,special_screen,world_map,special_icon,bag_panel)


class ReconnectWatch:
    def __init__(self,owner):self.owner=owner;self.active=False;self.job=None
    def stop(self):
        self.active=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None
    def start(self):
        self.stop();self.active=True;self.armed=True;self.hits=0;self.unknown_hits=0;self.last_mode=None
        self.job=self.owner.after(3000,self.tick)
    def tick(self):
        self.job=None
        if not self.active or not self.owner.daily_scheduler.active:return
        app=self.owner.winfo_toplevel();q=app.work_coordinator
        try:
            if q.active or q.pending or app.focus_runner.active or any(WorkCoordinator.busy(p) for p in app.profiles):return
            check_game_view(self.owner.window_link.hwnd)
            image=from_capture(capture(self.owner.window_link.hwnd))
            mode=auto_mode(image)
            valid=((auto_control(image)[0]>=.78 or mode=='on') and
                   (special_hud_timer(image)>=.78 or general_location(image,self.owner.general_key)>=.78) and
                   max(notice(image),shop(image),warehouse(image),special_screen(image),world_map(image),bag_panel(image))<.82 and
                   special_icon(image)[0]<.82)
            if not valid:
                self.hits=0;self.unknown_hits+=1
                if self.unknown_hits>=2:self.armed=True;self.last_mode=None
                return
            self.unknown_hits=0
            if mode=='off' and self.last_mode!='off':self.armed=True
            self.last_mode=mode
            self.hits=self.hits+1 if mode=='off' else 0
            if mode=='on':self.armed=False
            if self.armed and self.hits>=2:
                self.armed=False
                app.launch_recovery(app.profiles.index(self.owner),scheduled=True)
        except RuntimeError:
            # Covered/inactive game windows do not count as reconnect screens.
            self.hits=0
        finally:
            if self.active:self.job=self.owner.after(3000,self.tick)
