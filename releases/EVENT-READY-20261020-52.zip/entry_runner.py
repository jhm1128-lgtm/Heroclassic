from runner_timer import runner_after, invalidate
from focus_guard import lock,unlock
from attendance import dismiss_attendance, reset_attendance
"""One selected special-region entry and one AUTO enable, with observations."""
import time
import numpy as np
from runner_focus import ensure_view
from datetime import datetime
from pathlib import Path
from window_link import capture
from game_actions import check_game_view, click_client_point
from buy_runner import wallet, wallet_similarity
from special_runner import KEYS
from vision import (from_capture, special_screen, special_entry_dialog, region_card,
                    selected_card, special_floor_selected, special_remaining,
                    special_expired, auto_control, combat_active, notice, auto_mode)


class EntryRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        unlock(self)
        invalidate(self)
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, text):
        self.owner.town_log('[특수지역 입장] '+text)
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'special_entry.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} {getattr(self,"phase","idle")} {text}\n')
        except OSError:
            pass

    def start(self, chained=False):
        self.stop()
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        reset_attendance(self)
        self.active = True
        self.phase = 'inspect'
        self.hits = 0
        self.evidence = None
        self.expected = None
        self.confirm_selection = None
        self.confirm_heading = None
        self.payment_sent=False
        self.recovery_pending=False
        self.seen_combat = False
        self.combat_hits = 0
        self.hidden_since = None
        self.focus_retry_at = 0
        self.field_since = None
        self.off_hits = 0
        self.auto_attempts=0
        self.last_auto_at=0
        self.deadline = time.monotonic()+75
        self.limit = time.monotonic()+18
        try:lock(self)
        except RuntimeError as exc:
            self.finish(str(exc))
            return
        self.countdown(3)

    def countdown(self, seconds):
        self.job = None
        if not self.active:
            return
        if seconds:
            self.log(f'{seconds}초 후 시작 · 지정 층 또는 입장 확인창이 열린 게임을 활성화하세요.')
            self.job = runner_after(self,1000, lambda: self.countdown(seconds-1))
        else:
            self.tick()

    def later(self):
        self.job = runner_after(self,300, self.tick)

    def save(self, image, label):
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_entry_{label}.png')
        except OSError:
            pass

    def finish(self, message, image=None, continuing=False):
        retry=self.owner.cycle_runner.active and not continuing and hasattr(self.owner.cycle_runner,'retry_from_error')
        self.recovery_pending=bool(retry and getattr(self,'payment_sent',False))
        if self.owner.cycle_runner.active and not continuing and not retry:
            self.owner.cycle_runner.stop()
        self.stop()
        if image is not None:
            self.save(image, self.phase)
        self.log(message)
        if retry:self.owner.cycle_runner.fail(message)

    def change_phase(self, phase, timeout):
        self.phase = phase
        self.limit = time.monotonic()+timeout
        self.hits = 0
        self.evidence = None

    def selection(self, image):
        found = []
        for index, key in enumerate(KEYS):
            score, left, top = region_card(image, key)
            if score >= .78 and selected_card(image, left, top):
                name, level = self.owner.routes[index]
                floor = int(level.replace('층',''))
                if not special_floor_selected(image, floor):
                    raise RuntimeError(f'{name}의 설정 층 {level}이 선택되지 않았습니다. 층 선택 단계부터 확인하세요.')
                found.append((index, name, level, left, top))
        if len(found) != 1:
            raise RuntimeError(f'선택 지역을 하나로 확인하지 못했습니다({len(found)}개). 입장하지 않습니다.')
        return found[0]

    def stable(self, evidence):
        self.hits = self.hits+1 if evidence == self.evidence else 1
        self.evidence = evidence
        return self.hits >= 2

    def confirm(self, image, selected):
        self.expected = selected[:3]
        self.before_wallet = wallet(image)
        self.save(image, 'before_confirm')
        click_client_point(self.handle, .622, .643)
        self.payment_sent=True
        self.log(f'{selected[1]} {selected[2]}·입장 문구·지불 엽전 확인 → 확인 1회')
        self.change_phase('arrival', 25)

    def tick(self):
        self.job = None
        if not self.active:
            return
        image = None
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결 대상이 변경되어 중지했습니다.')
            if not ensure_view(self,check_game_view):
                self.later()
                return
            image = from_capture(capture(self.handle))
            if dismiss_attendance(self,image):
                self.later()
                return
            now = time.monotonic()
            if now > self.deadline or now > self.limit:
                raise RuntimeError(f'{self.phase} 확인 시간 초과 · 입장 반복 없이 현재 상태 복구 대기로 전환합니다.')
            title, cost = special_entry_dialog(image)
            dialog = title >= .86 and cost >= .80
            screen = special_screen(image)
            if notice(image) >= .82:
                raise RuntimeError('알림창이 나타났습니다. 입장이나 AUTO를 추가로 누르지 않습니다.')
            if self.phase in ('inspect','confirm'):
                if screen < .85:
                    raise RuntimeError('특수지역 화면을 확인하지 못해 입장하지 않습니다.')
                if dialog and self.phase == 'confirm' and self.confirm_selection is not None:
                    # The payment modal overlaps the card terrain. Reuse only
                    # our own verified entry target; its uncovered detail name
                    # and selected floor must still agree before payment.
                    selected = self.confirm_selection
                    heading = np.asarray(image.convert('L'),dtype=float)[105:132,230:460]
                    a = self.confirm_heading-self.confirm_heading.mean()
                    b = heading-heading.mean()
                    denominator = np.linalg.norm(a)*np.linalg.norm(b)
                    similarity = float(np.sum(a*b)/denominator) if denominator>1 else 0
                    if similarity < .92 or not special_floor_selected(image,int(selected[2].replace('층',''))):
                        raise RuntimeError('확인창 뒤 지역명·지정 층이 입장 직전과 달라 확인을 보류합니다.')
                else:
                    selected = self.selection(image)
                if self.expected is not None and selected[:3] != self.expected:
                    raise RuntimeError('입장 대기 중 선택 지역/층이 달라져 중지했습니다.')
                if dialog:
                    if self.stable(('dialog',)+selected[:3]):
                        self.confirm(image, selected)
                elif self.phase == 'inspect':
                    remaining = special_remaining(image)[0]
                    card, detail = special_expired(image, selected[3], selected[4])
                    if not remaining or card >= .78 or detail >= .78:
                        raise RuntimeError('남은 시간을 확인하지 못했거나 만료 표시가 있어 입장하지 않습니다.')
                    if self.stable(('ready',)+selected[:3]):
                        self.expected = selected[:3]
                        self.confirm_selection = selected
                        self.confirm_heading = np.asarray(image.convert('L'),dtype=float)[105:132,230:460].copy()
                        click_client_point(self.handle, .85, .95)
                        self.log(f'{selected[1]} {selected[2]} 선택·남은 시간 확인 → 입장 1회 → 확인창 대기')
                        self.change_phase('confirm', 12)
                else:
                    self.hits = 0
            elif self.phase == 'arrival':
                correlation = wallet_similarity(self.before_wallet, wallet(image))
                auto_score, x, y = auto_control(image)
                ready = not dialog and screen < .70 and correlation < .98 and auto_score >= .78
                if ready and self.field_since is None:self.field_since=now
                if not ready:self.field_since=None
                self.hits = self.hits+1 if ready else 0
                if ready:
                    combat = combat_active(image)
                    mode = auto_mode(image)
                    self.off_hits = self.off_hits+1 if mode=='off' else 0
                    if combat >= .80 or mode=='on':
                        self.seen_combat = True
                        self.combat_hits += 1
                    else:
                        self.combat_hits = 0
                    if self.combat_hits >= 2:
                        self.complete(image)
                        return
                    if self.hits >= 3 and self.off_hits>=3 and not self.seen_combat and now-self.field_since>=1:
                        self.save(image, 'before_auto')
                        click_client_point(self.handle, x/800, y/600)
                        self.auto_attempts=1
                        self.last_auto_at=now
                        self.off_hits=0
                        self.log('입장창 닫힘·재화 표시 변화·필드 화면 확인 → AUTO 1회 클릭')
                        self.change_phase('combat', 30)
            elif self.phase == 'combat':
                combat = combat_active(image)
                mode=auto_mode(image)
                self.combat_hits = self.combat_hits+1 if combat >= .80 or mode=='on' else 0
                if self.combat_hits >= 2:
                    self.complete(image)
                    return
                hud,x,y=auto_control(image)
                off=(mode=='off' and combat<.80 and hud>=.78 and not dialog and screen<.70)
                self.off_hits=self.off_hits+1 if off else 0
                if self.off_hits>=3 and self.auto_attempts<3 and now-self.last_auto_at>=3:
                    click_client_point(self.handle,x/800,y/600)
                    self.auto_attempts+=1
                    self.last_auto_at=now
                    self.off_hits=0
                    self.log(f'AUTO 꺼짐 재확인 → 재시도 {self.auto_attempts}/3 · 켜짐 확인 대기')
            self.later()
        except Exception as exc:
            self.finish(str(exc), image)

    def complete(self, image):
        index, name, floor = self.expected
        self.owner.tree.set(self.owner.rows[index+2], 'state', '자동 전투 확인')
        chained = self.owner.cycle_runner.active
        self.finish(f'{name} {floor} 입장 처리·자동 전투 중 표시 연속 확인 완료.', image, continuing=chained)
        if chained:
            self.owner.cycle_runner.wait_for_return(self.expected)
