from runner_timer import runner_after, invalidate
from focus_guard import lock,unlock
from attendance import dismiss_attendance, reset_attendance
"""Resume AUTO only in an identified existing field; never reenter or pay."""
import time
from pathlib import Path
from datetime import datetime
from window_link import capture
from runner_focus import ensure_view
from game_actions import check_game_view,click_client_point
from vision import (from_capture,auto_control,auto_mode,combat_active,special_hud_timer,
                    general_location,notice,shop,warehouse,special_screen,world_map,
                    quest_travel,special_icon,bag_panel)


class RecoveryRunner:
    def __init__(self,owner):
        self.owner=owner;self.active=False;self.job=None

    def stop(self):
        unlock(self)
        invalidate(self)
        self.active=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None

    def log(self,text):
        self.owner.town_log('[AUTO 복구] '+text)

    def start(self,require='any',done=None):
        self.stop()
        self.handle=self.owner.window_link.hwnd
        reset_attendance(self)
        self.require=require;self.done=done
        self.phase='check';self.hits=0;self.on_hits=0;self.off_hits=0
        self.field_since=None;self.hidden_since=None;self.focus_retry_at=0
        self.auto_attempts=0;self.last_auto_at=0
        self.deadline=time.monotonic()+50;self.limit=self.deadline
        self.active=True
        try:lock(self)
        except RuntimeError as exc:
            self.finish(False,str(exc))
            return
        self.log('현재 사냥터와 AUTO 상태 확인 · 이동·재입장 없이 복구')
        self.job=runner_after(self,900,self.tick)

    def finish(self,success,text,image=None):
        done=self.done;self.done=None
        self.stop();self.log(text)
        if image is not None:
            try:
                folder=Path(__file__).resolve().parent/'diagnostics';folder.mkdir(exist_ok=True)
                image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_recovery.png')
            except OSError:pass
        if done is not None:done(success)

    def tick(self):
        self.job=None
        if not self.active:return
        image=None
        try:
            if self.handle!=self.owner.window_link.hwnd:raise RuntimeError('연결 창 변경')
            if not ensure_view(self,check_game_view):
                self.job=runner_after(self,900,self.tick);return
            image=from_capture(capture(self.handle));now=time.monotonic()
            if dismiss_attendance(self,image):
                self.job=runner_after(self,900,self.tick);return
            if now>self.limit:raise RuntimeError('AUTO 확인 시간 초과 · 추가 클릭 없음')
            blocked=(max(notice(image),shop(image),warehouse(image),special_screen(image),
                         world_map(image),quest_travel(image),bag_panel(image))>=.82 or special_icon(image)[0]>=.82)
            hud,x,y=auto_control(image)
            mode=auto_mode(image)
            special=special_hud_timer(image)>=.78
            general=general_location(image,self.owner.general_key)>=.78 and not special
            valid=(hud>=.78 or mode=='on') and not blocked and (special if self.require=='special' else general if self.require=='general' else special or general)
            if not valid:
                self.hits=0;self.on_hits=0;self.off_hits=0;self.field_since=None
                # The startup check is harmless in town, menus or a login screen.
                if self.phase=='check':self.finish(False,'현재 사냥터 확인 불가 · 이동/AUTO 입력 없이 종료',image);return
            else:
                if self.field_since is None:self.field_since=now
                self.hits+=1
                enabled=mode=='on' or combat_active(image)>=.80
                self.on_hits=self.on_hits+1 if enabled else 0
                self.off_hits=self.off_hits+1 if mode=='off' and not enabled else 0
                if self.on_hits>=2:
                    self.finish(True,'AUTO 켜짐 연속 확인 · 복구 완료',image);return
                initial=self.phase=='check' and self.off_hits>=3 and now-self.field_since>=1
                retry=self.phase=='verify' and self.off_hits>=3 and self.auto_attempts<3 and now-self.last_auto_at>=3
                if initial or retry:
                    click_client_point(self.handle,x/800,y/600)
                    self.auto_attempts+=1;self.last_auto_at=now;self.off_hits=0
                    self.phase='verify'
                    if initial:self.limit=now+30
                    self.log(f'AUTO 꺼짐 연속 확인 → 클릭 {self.auto_attempts}/3 · 켜짐 확인 대기')
            self.job=runner_after(self,900,self.tick)
        except Exception as exc:self.finish(False,str(exc),image)
