"""Bounded background Telegram delivery. No retries after ambiguous failures."""
import json,queue,threading,urllib.request,urllib.error
from telegram_config import validate
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

def send_message(token,chat,text):
    validate(token,chat)
    data=json.dumps(dict(chat_id=chat,text=text[:4000]),ensure_ascii=False).encode('utf-8')
    request=urllib.request.Request('https://api.telegram.org/bot'+token+'/sendMessage',data=data,headers={'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.build_opener(NoRedirect).open(request,timeout=10) as response:
            result=json.loads(response.read(1024*1024))
        if result.get('ok') is not True:raise RuntimeError('Telegram API가 전송을 거절했습니다. 토큰·수신 대상을 확인하세요.')
    except urllib.error.HTTPError as exc:raise RuntimeError('Telegram 전송 거절: HTTP '+str(exc.code)) from None
    except (urllib.error.URLError,TimeoutError,OSError):raise RuntimeError('Telegram 네트워크 연결 실패/시간 초과 · 중복 방지를 위해 자동 재전송하지 않습니다.') from None
    except (ValueError,KeyError):raise RuntimeError('Telegram 응답 확인 실패') from None

class Sender:
    def __init__(self,send=send_message):
        self.send=send;self.jobs=queue.Queue(maxsize=50);self.results=queue.Queue();self.generation=0
        self.delivered=set();self.closed=False
        threading.Thread(target=self.run,daemon=True).start()
    def cancel(self):self.generation+=1
    def enqueue(self,token,chat,text,kind='test',key=None):
        if self.closed:return False
        try:self.jobs.put_nowait((self.generation,token,chat,text,kind,key));return True
        except queue.Full:self.results.put((False,'Telegram 전송 대기열이 가득 찼습니다.'));return False
    def run(self):
        while True:
            item=self.jobs.get()
            if item is None:return
            generation,token,chat,text,kind,key=item
            if self.closed or generation!=self.generation:continue
            if kind=='recovery' and key not in self.delivered:continue
            try:
                self.send(token,chat,text)
                if kind=='alert':self.delivered.add(key)
                if kind=='recovery':self.delivered.discard(key)
                self.results.put((True,'Telegram '+('시험' if kind=='test' else '복구' if kind=='recovery' else '경고')+' 메시지 전송 완료'))
            except Exception:
                # Exceptions can contain the request URL/token. Never expose them.
                self.results.put((False,'Telegram 전송 실패 · 토큰/채팅 ID와 네트워크를 확인하세요. 자동 재전송 없음'))
    def close(self):
        self.closed=True;self.cancel()
        try:self.jobs.put_nowait(None)
        except queue.Full:pass
