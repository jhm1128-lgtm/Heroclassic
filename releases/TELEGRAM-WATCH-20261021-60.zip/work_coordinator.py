"""Serialize foreground actions without cancelling the other hunt observer."""
import time
from focus_guard import focus_allowed,observation_interval,switching_paused
from collections import deque
from pathlib import Path
from datetime import datetime


class WorkCoordinator:
    def __init__(self, app):
        self.app = app
        self.pending = deque()
        self.active = False
        self.current = None
        self.job = None
        self.next_start = 0

    @staticmethod
    def busy(profile):
        if getattr(getattr(profile,'observation_menu_runner',None),'active',False):return True
        if getattr(getattr(profile,'recovery_runner',None),'active',False):return True
        event=getattr(profile,'event_runner',None)
        if event is not None and event.active and event.phase!='observe':return True
        if any(getattr(profile, name).active for name in
               ('supply_runner','special_runner','entry_runner','general_runner',
                'npc_runner','store_runner','jumo_runner','buy_runner','auto_runner')):
            return True
        cycle=profile.cycle_runner
        return cycle.active and getattr(cycle,'phase',None) not in ('observe','retry_wait')

    def log(self, request, text):
        self.app.profiles[request['index']].town_log('[창별 작업] '+text)
        try:
            folder=Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'dual_work.log').open('a',encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} 창{request["handle"]} {text}\n')
        except OSError:
            pass

    def submit(self, index, kind, action, failed=None, scheduled=False,priority=False):
        if any(r['index']==index and r['kind']==kind for r in
               list(self.pending)+([self.current] if self.current else [])):
            return
        profile=self.app.profiles[index]
        request=dict(index=index,kind=kind,action=action,failed=failed,
                     scheduled=scheduled,handle=profile.window_link.hwnd,
                     priority=priority,
                     not_before=0)
        if priority:self.pending.appendleft(request)
        else:self.pending.append(request)
        self.log(request, kind+' 대기 등록 · 다른 창 진행 상태 유지')
        self.schedule()

    def cancel_scheduled(self, index):
        self.pending=deque(r for r in self.pending
                           if not (r['index']==index and r['scheduled']))

    def cancel_events(self,index):
        self.pending=deque(r for r in self.pending if not (r['index']==index and r['kind'].startswith('이벤트')))

    def stop(self):
        self.pending.clear()
        self.current=None
        self.active=False
        self.next_start=0
        if self.job is not None:
            self.app.after_cancel(self.job)
            self.job=None

    def schedule(self):
        if self.job is None and (self.active or self.pending):
            self.job=self.app.after(1000,self.tick)

    def fail(self, request, text):
        self.log(request,text)
        if request['failed'] is not None:
            request['failed'](text)
        if self.current is request:
            self.current=None
            self.active=False

    def tick(self):
        self.job=None
        if getattr(self,'ticking',False) or getattr(self.app,'automation_callback',None) is not None:
            self.schedule()
            return
        self.ticking=True
        try:self.tick_once()
        finally:self.ticking=False

    def tick_once(self):
        self.job=None
        if self.active:
            request=self.current
            profile=self.app.profiles[request['index']]
            if profile.window_link.hwnd != request['handle']:
                profile.stop()
                self.fail(request,'연결 창 변경으로 해당 창 작업 중지')
            elif self.app.focus_runner.active or self.busy(profile):
                self.schedule()
                return
            else:
                self.log(request,request['kind']+' 조작 구간 종료')
                self.active=False
                self.current=None
        if (not self.pending or switching_paused(self.app) or self.app.focus_runner.active or
                any(self.busy(p) for p in self.app.profiles)):
            self.schedule()
            return
        request=next((r for r in self.pending if r['not_before'] <= time.monotonic()
                      and (r['priority'] or time.monotonic()>=self.next_start)),None)
        if request is None:
            self.schedule()
            return
        if not focus_allowed(self.app,request['handle']):
            self.schedule()
            return
        self.pending.remove(request)
        profile=self.app.profiles[request['index']]
        if not request['handle'] or profile.window_link.hwnd != request['handle']:
            self.fail(request,'연결된 게임 창을 확인할 수 없어 해당 요청 중지')
            self.schedule()
            return
        self.active=True
        self.current=request
        # Only this profile's pending observer/action is replaced.
        profile.stop()
        self.app.mode.set(request['kind']+' · 창 전환 대기')

        def ready():
            if self.current is not request:
                return
            if profile.window_link.hwnd != request['handle']:
                self.fail(request,'전환 중 연결된 게임 창 변경')
                return
            now=time.monotonic()
            self.next_start=now
            if self.app.dual_runner.active:
                self.app.dual_runner.current=request['index']
                self.app.dual_runner.due=now+observation_interval(self.app)
            self.app.mode.set(request['kind'])
            self.log(request,'활성화 확인 → '+request['kind']+' 시작')
            try:
                request['action']()
            except Exception as exc:
                self.fail(request,str(exc))

        def failed(text):
            if self.current is request:
                if text.startswith('창 전환 확인 시간 초과'):
                    self.current=None
                    self.active=False
                    request['not_before']=time.monotonic()+30
                    self.pending.append(request)
                    self.log(request,text+' · 요청 유지, 30초 뒤 다시 시도 · 대기시간 초과로 취소하지 않습니다.')
                    self.app.mode.set('예약 유지 · 창 전환 재시도 대기')
                else:
                    self.fail(request,text)

        self.app.focus_runner.start(request['handle'],ready,failed,profile.town_log)
        self.schedule()
