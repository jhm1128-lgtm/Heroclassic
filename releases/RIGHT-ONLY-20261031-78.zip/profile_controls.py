"""Independent reservation toggles; game AUTO is never toggled by OFF."""
def toggle_profile(app,index):
    p=app.profiles[index]
    if p.daily_scheduler.active:
        app.work_coordinator.cancel_profile(index)
        p.stop(cancel_schedule=True)
        p.automation_state='off'
        if not any(q.daily_scheduler.active for q in app.profiles):
            app.automation_state='off'
            app.dual_runner.stop()
        p.town_log('[캐릭터 자동화] 꺼짐 · 해당 캐릭터 예약/조작 중지 · 게임 AUTO 유지')
    else:
        app.arm_daily(index)
        if p.daily_scheduler.active:
            p.automation_state='on';app.automation_state='on'
    app.refresh_shared_status_values()
