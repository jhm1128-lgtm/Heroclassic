"""Attach the normal route after the automation-start AUTO check."""
from event_schedule import events_for


def resume_route(app,index,field):
    profile=app.profiles[index]
    if not profile.daily_scheduler.active:return
    scheduler=getattr(profile,'event_scheduler',None)
    if scheduler is not None and scheduler.active:
        now=scheduler.now()
        if any(e.start<=now.time()<e.end for e in events_for(profile.right,now.date())):
            if field in ('town','general'):scheduler.recheck_from_field(field)
            profile.town_log('[자동화 시작] 현재 이벤트 시간 · 현재 위치에 맞춰 이벤트 예약의 확인·진입 흐름 연결')
            return
    if field=='event_return':
        profile.town_log('[자동화 시작] 이벤트 복귀 위치 확인 → 설정 일반사냥터 이동·AUTO 확인')
        app.launch_general(index)
        return
    if field not in ('special','town'):
        profile.town_log('[자동화 시작] '+('일반사냥 위치 확인 · 현재 사냥 유지' if field=='general' else
                                       '현재 위치 확인 불가 · 임의 이동 없이 화면 확인 대기'))
        return
    daily=profile.daily_scheduler
    if field=='town' and daily.now().time()<daily.special_time:
        profile.town_log('[자동화 시작] 특수지역 예약 시각 전 · 현재 마을 유지, 예약 일정 대기')
        return
    profile.town_log('[자동화 시작] '+('현재 특수지역 AUTO 확인 후 종료 관찰 연결' if field=='special' else
                                   '한밭마을 확인 → 남은 특수지역 검사, 모두 만료면 일반사냥 연결'))
    app.launch_remaining(index,scheduled=True)
