from runner_timer import runner_after, invalidate
from focus_guard import focus_allowed,switching_paused
"""Wait asynchronously for an authorized, visible game foreground."""
import time
from pathlib import Path
from datetime import datetime
from game_actions import request_game_foreground, check_game_view, u


class FocusRunner:
    def __init__(self, app):
        self.app = app
        self.active = False
        self.job = None

    def stop(self):
        invalidate(self)
        self.active = False
        if self.job is not None:
            self.app.after_cancel(self.job)
            self.job = None

    def log(self, text):
        self.say('[게임 창 전환] '+text)
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'window_focus.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} {text}\n')
        except OSError:
            pass

    def start(self, handle, ready, failed, say):
        if not focus_allowed(self.app,handle,ignore_pause=True):
            failed('창 전환 확인 시간 초과 · 다른 캐릭터 입장/AUTO 확인 보호 중 · 전환 보류')
            return False
        self.stop()
        self.handle = handle
        self.ready = ready
        self.failed = failed
        self.say = say
        self.active = True
        self.deadline = time.monotonic()+12
        self.last_reason = '전환 완료 대기'
        self.hinted = False
        self.requested = False
        self.attempts = 0
        self.next_request = time.monotonic()
        self.hits = 0
        self.switch_pause_since=None
        self.log(f'대상 창 ID {handle} 전환 준비 · 게임 입력은 활성화 확인 뒤 시작합니다.')
        # Return from the GUI button event before asking Windows to switch.
        self.job = runner_after(self,150, self.tick)

    def tick(self):
        self.job = None
        if not self.active:
            return
        if switching_paused(self.app):
            if self.switch_pause_since is None:self.switch_pause_since=time.monotonic()
            self.job=runner_after(self,500,self.tick)
            return
        if self.switch_pause_since is not None:
            delay=time.monotonic()-self.switch_pause_since
            self.deadline+=delay;self.next_request+=delay
            self.switch_pause_since=None
        if not focus_allowed(self.app,self.handle):
            failed=self.failed
            self.stop()
            failed('창 전환 확인 시간 초과 · 입장/AUTO 보호 중 시작 전 전환 보류')
            return
        if self.attempts < 3 and time.monotonic() >= self.next_request:
            try:
                accepted = request_game_foreground(self.handle)
                self.requested = True
                self.attempts += 1
                self.next_request = time.monotonic()+3
                method=getattr(request_game_foreground,'last_method','일반 전환')
                self.log(f'전환 요청 {self.attempts}/3 · {method} · 결과 {accepted} · 대상 {self.handle} / 현재 {u.GetForegroundWindow()} · 완료 확인 대기')
            except RuntimeError as exc:
                self.stop()
                self.failed(str(exc))
                return
        try:
            check_game_view(self.handle)
            self.hits += 1
        except RuntimeError as exc:
            self.hits = 0
            self.last_reason = str(exc)
        if self.hits >= 2:
            self.stop()
            self.log(f'대상 창 ID {self.handle} 활성화·가려짐 없음 연속 확인 완료')
            self.ready()
            return
        now = time.monotonic()
        if now >= self.deadline:
            self.stop()
            message=f'창 전환 확인 시간 초과 · 대상 {self.handle} / 현재 {u.GetForegroundWindow()} · {self.last_reason} · 게임 입력 없음'
            self.log(message)
            self.failed(message)
            return
        if not self.hinted and self.deadline-now <= 9:
            self.hinted = True
            self.log('자동 전환 대기 중입니다. 해당 게임을 클릭하고 다른 창에 가리지 않으면 남은 대기 시간 안에 자동으로 이어집니다. 버튼은 다시 누르지 마세요.')
        self.job = runner_after(self,150, self.tick)
