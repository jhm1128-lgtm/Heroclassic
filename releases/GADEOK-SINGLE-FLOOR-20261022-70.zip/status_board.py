"""Read automation state only; never capture or activate game windows."""
from focus_guard import switching_paused

PHASES = {'inspect':'선택·시간 확인', 'confirm':'입장 확인', 'arrival':'입장 완료·AUTO 준비',
          'combat':'AUTO 켜짐 확인', 'check':'현재 AUTO 확인', 'verify':'AUTO 켜짐 확인',
          'find':'목록 만료 확인', 'align_top':'목록 위쪽 정렬', 'prepare_confirm':'남은 지역 확인',
          'floor_check':'지정 층 확인', 'retry_wait':'복구 재시도 대기',
          'observe':'사냥 중 · 종료 확인 대기', 'refresh_wait':'이용중 표시 갱신 대기',
          'identify_existing':'현재 사냥 유지 · 지역/AUTO 확인 대기 · 재입장 없음'}


def profile_status(app,index):
    p=app.profiles[index]
    queue=app.work_coordinator
    # Active input remains the owner even if more requests are queued.
    for name,label in [('observation_menu_runner','사냥 관찰 메뉴 정리'),('entry_runner','특수지역'),('recovery_runner','AUTO 복구'),
                       ('special_runner','특수지역'),('supply_runner','상점창고'),
                       ('general_runner','일반사냥'),('npc_runner','복자할매'),
                       ('store_runner','창고'),('jumo_runner','주모'),
                       ('buy_runner','구매'),('auto_runner','AUTO')]:
        runner=getattr(p,name,None)
        if runner is not None and runner.active:
            if name=='entry_runner' and getattr(runner,'expected',None):
                label+=' '+runner.expected[1]+' '+runner.expected[2]
            elif name=='special_runner':
                routes=getattr(runner,'routes',p.routes)
                place,floor=routes[min(getattr(runner,'index',0),len(routes)-1)]
                label+=' '+place+' '+floor
            phase=getattr(runner,'phase','')
            detail=PHASES.get(phase,'진행 중')
            hidden=getattr(runner,'hidden_since',None) is not None
            wait=' · 창 전환 멈춤' if switching_paused(app) and hidden else ' · 창 활성화 대기' if hidden else ''
            return label+' · '+detail+wait
    pending=next((r for r in queue.pending if r['index']==index),None)
    current=queue.current
    if pending is not None:
        reason='창 전환 멈춤' if switching_paused(app) else '다른 창 작업 완료 후 진행' if queue.active and current and current['index']!=index else '순서 대기'
        return '대기열 · '+pending['kind']+' · '+reason
    if queue.active and current and current['index']==index:
        return current['kind']+' · 창 활성화·시작 확인'
    for name,label in [('event_runner','이벤트 특수지역'),('cycle_runner','특수지역')]:
        runner=getattr(p,name,None)
        if runner is not None and runner.active:
            phase=getattr(runner,'phase','')
            region=getattr(runner,'required_expired',None)
            if name=='cycle_runner' and isinstance(region,int) and 0<=region<len(p.routes):
                expected=getattr(runner,'current_expected',None)
                place,floor=expected[1:] if expected is not None else p.routes[region]
                label+=' '+place+' '+floor
            return label+' · '+PHASES.get(phase,'진행 중')
    scheduler=getattr(p,'event_scheduler',None)
    if scheduler is not None and scheduler.active:
        if getattr(scheduler,'return_check',None) is not None:
            return '이벤트 종료 · 게임 자동 복귀 대기 / 일반사냥 AUTO 확인 · 추가 이동 없음'
        now=scheduler.now()
        for key,at in getattr(scheduler,'retry_after',{}).items():
            if key[0]==now.date() and key not in scheduler.attempted:
                from event_schedule import events_for
                event=next((event for event in events_for(p.right,now.date()) if event.key==key[1]),None)
                if event and now.time()<event.end:
                    seconds=max(0,int((at-now).total_seconds()))
                    return '이벤트 '+event.name+' · 입장 전 재시도 '+str(seconds)+'초 대기'
    return p.status.get()
