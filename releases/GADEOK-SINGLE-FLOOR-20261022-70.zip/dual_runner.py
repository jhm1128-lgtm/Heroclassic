from runner_timer import runner_after, invalidate
from focus_guard import focus_allowed,observation_interval,switching_paused
"""One-minute foreground turns; each profile owns its own hunt state."""
import time
from window_link import bounds, u


class DualRunner:
    def __init__(self, app):
        self.app = app
        self.active = False
        self.job = None

    def stop(self):
        invalidate(self)
        self.active = False
        if self.job is not None:
            self.app.after_cancel(self.job)
            self.job = None

    def start(self):
        self.stop()
        self.app.auto_connect()
        profiles = self.app.profiles
        handles = [p.window_link.hwnd for p in profiles]
        if not all(handles) or len(set(handles)) != 2:
            profiles[0].town_log('[두 창 교대] 서로 다른 두 게임 창을 각 탭에 연결하세요.')
            return
        try:
            for handle in handles:
                bounds(handle)
        except RuntimeError as exc:
            profiles[0].town_log('[두 창 교대] '+str(exc))
            return
        self.active = True
        self.app.mode.set("양쪽 예약 대기 · 일반 사냥 유지")
        self.handles = handles
        self.started = [True, True]
        self.current = 1
        self.watching = ()
        self.interval=observation_interval(self.app)
        self.due = time.monotonic()+3
        profiles[0].town_log('[창 관리] 주기적 창 전환 없음 · 예약·다음 지역·AUTO 작업이 필요할 때만 활성화')
        self.job = runner_after(self,3000, self.tick)

    @staticmethod
    def observing(profile):
        return any(r is not None and r.active and getattr(r,'phase',None)=='observe'
                   for r in (profile.cycle_runner,getattr(profile,'event_runner',None)))

    @staticmethod
    def busy(profile):
        if getattr(getattr(profile,'observation_menu_runner',None),'active',False):return True
        if getattr(getattr(profile,'recovery_runner',None),'active',False):return True
        event=getattr(profile,'event_runner',None)
        if event is not None and event.active and event.phase!='observe':return True
        return (any(getattr(profile, name).active for name in
                   ('supply_runner','special_runner','entry_runner','general_runner','npc_runner',
                    'store_runner','jumo_runner','buy_runner','auto_runner')) or
                (profile.cycle_runner.active and getattr(profile.cycle_runner,'phase',None) not in ('observe','retry_wait')))

    def activation_ready(self, target):
        if not self.active:
            return
        profile = self.app.profiles[target]
        if profile.window_link.hwnd != self.handles[target]:
            self.activation_failed('전환 대기 중 연결된 창이 바뀌었습니다.')
            return
        self.current = target
        self.last_focus_at=time.monotonic()
        self.due = time.monotonic()+observation_interval(self.app)
        self.app.mode.set('특수지역 관찰 · 필요한 창만 전환')
        profile.town_log('[두 창 교대] '+('왼쪽' if target == 0 else '오른쪽')+f' 게임 활성화 확인 · 다음 관찰은 {observation_interval(self.app)//60}분 뒤')
        if not self.started[target]:
            self.started[target] = True
            profile.cycle_runner.start_remaining(chained=True)

    def activation_failed(self, message):
        if message.startswith('창 전환 확인 시간 초과'):
            self.due=time.monotonic()+30
            self.app.mode.set('양쪽 예약 유지 · 창 전환 대기')
            self.app.profiles[0].town_log('[두 창 교대] '+message+' · 예약 유지, 30초 뒤 재시도')
        else:
            self.stop()
            self.app.mode.set('교대 중지 (게임 연결 확인 필요)')
            self.app.profiles[0].town_log('[두 창 교대] '+message)

    def tick(self):
        self.job = None
        if not self.active:
            return
        if [p.window_link.hwnd for p in self.app.profiles] != self.handles:
            self.activation_failed('연결된 게임 창이 바뀌었습니다. 교대를 중지합니다.')
            return
        interval=observation_interval(self.app)
        if interval!=self.interval:
            self.interval=interval
            self.due=max(time.monotonic(),getattr(self,'last_focus_at',time.monotonic())+interval)
        watching=tuple(i for i,p in enumerate(self.app.profiles) if self.observing(p) and not
                       (p.cycle_runner.active and p.cycle_runner.phase=='observe' and
                        getattr(p.cycle_runner,'passive_visible',False) and
                        not getattr(getattr(p,'event_runner',None),'active',False)))
        available=(not switching_paused(self.app) and not self.app.focus_runner.active
                and not self.app.work_coordinator.active and not self.app.work_coordinator.pending
                and not any(self.busy(p) for p in self.app.profiles))
        if available and watching != self.watching:
            if not watching:
                self.app.mode.set('양쪽 예약 대기 · 일반 사냥 유지')
                self.app.profiles[0].town_log('[두 창 교대] 특수지역 관찰 없음 · 창 전환 쉬는 중 · 다음 예약은 유지합니다.')
            else:
                self.app.mode.set('특수지역 관찰 · 필요한 창만 전환')
            self.watching=watching
        # No clock-based focus changes. WorkCoordinator owns necessary
        # transitions; observers only inspect already exposed HUDs.
        self.job = runner_after(self,1000, self.tick)
