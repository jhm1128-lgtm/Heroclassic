"""Independent saved daily-region floors; no game input on edits."""
import json
from pathlib import Path

SETTINGS=Path(__file__).resolve().parent/'hunting_floors.json'


def read_settings():
    try:
        value=json.loads(SETTINGS.read_text(encoding='utf-8'))
        return value if isinstance(value,dict) else {}
    except (OSError,ValueError):return {}


def load_routes(defaults,right):
    data=read_settings().get('profiles',{})
    record=data.get('right' if right else 'left',{}) if isinstance(data,dict) else {}
    if not isinstance(record,dict):record={}
    routes=[]
    for name,default in defaults:
        floor=record.get(name)
        routes.append((name,str(floor)+'층' if type(floor) is int and 1<=floor<=4 else default))
    return routes


def save_routes(routes,right):
    record={name:int(level.replace('층','')) for name,level in routes}
    if any(not 1<=floor<=4 for floor in record.values()):raise ValueError('1~4층만 선택할 수 있습니다.')
    data=read_settings()
    if not isinstance(data.get('profiles'),dict):data['profiles']={}
    data['version']=1
    data['profiles']['right' if right else 'left']=record
    temporary=SETTINGS.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    temporary.replace(SETTINGS)
