from runner_timer import runner_after, invalidate
"""Explicit one-shot AUTO start from an already entered hunting field."""
from datetime import datetime
from pathlib import Path
import time
from window_link import capture
from game_actions import check_game_view, click_client_point
from vision import from_capture, special_screen, special_entry_dialog, auto_control, combat_active, notice


class AutoRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        invalidate(self)
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, text):
        self.owner.town_log('[현재 사냥터 AUTO] '+text)
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'auto_field.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} {text}\n')
        except OSError:
            pass

    def save(self, image, label):
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_auto_field_{label}.png')
        except OSError:
            pass

    def start(self):
        self.stop()
        self.owner.winfo_toplevel().stop_all()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.owner.winfo_toplevel().auto_connect()
            self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        self.active = True
        self.phase = 'ready'
        self.hits = 0
        self.combat_hits = 0
        self.seen_combat = False
        self.previous = None
        self.verify_frames = 0
        self.deadline = time.monotonic()+22
        self.countdown(3)

    def countdown(self, seconds):
        self.job = None
        if not self.active:
            return
        if seconds:
            self.log(f'{seconds}초 후 시작 · AUTO를 꺼둔 게임 화면을 활성화하세요. 입장은 다시 하지 않습니다.')
            self.job = runner_after(self,1000, lambda: self.countdown(seconds-1))
        else:
            self.tick()

    def finish(self, text, image=None):
        self.stop()
        if image is not None:
            self.save(image, self.phase)
        self.log(text)

    def tick(self):
        self.job = None
        if not self.active:
            return
        image = None
        try:
            if self.owner.window_link.hwnd != self.handle:
                raise RuntimeError('연결 창이 달라져 중지했습니다.')
            check_game_view(self.handle)
            image = from_capture(capture(self.handle))
            now = time.monotonic()
            if notice(image) >= .82 or special_screen(image) >= .70:
                raise RuntimeError('메뉴/알림이 아닌 사냥터 화면에서 실행하세요.')
            title, cost = special_entry_dialog(image)
            if title >= .86 and cost >= .80:
                raise RuntimeError('입장 확인창에서는 AUTO를 누르지 않습니다.')
            score, x, y = auto_control(image)
            combat = combat_active(image)
            self.combat_hits = self.combat_hits+1 if combat >= .80 else 0
            self.seen_combat = self.seen_combat or combat >= .80
            if self.combat_hits >= 2:
                self.finish('자동 전투 중 표시 연속 확인 완료 · AUTO를 추가로 누르지 않습니다.', image)
                return
            if now > self.deadline:
                if self.phase == 'verify':
                    self.finish('AUTO 클릭은 1회 전송했습니다. 자동 전투 중 문구는 확인하지 못했으므로 실제 전투 상태를 확인해야 합니다. 추가 클릭은 하지 않습니다.', image)
                    return
                raise RuntimeError('필드/AUTO 확인 시간 초과 · AUTO를 반복하지 않습니다.')
            if self.phase == 'ready':
                if score < .78:
                    raise RuntimeError(f'AUTO 버튼 확인 미달 {score:.3f} · 클릭하지 않았습니다.')
                current = (round(x), round(y))
                self.hits = self.hits+1 if self.previous == current else 1
                self.previous = current
                if self.hits >= 2 and not self.seen_combat:
                    self.save(image, 'before_click')
                    detail = click_client_point(self.handle, x/800, y/600)
                    self.log(f'AUTO 버튼 연속 확인 {score:.3f} → 클릭 1회 · {detail}')
                    self.phase = 'verify'
                    self.deadline = now+10
            else:
                self.verify_frames += 1
                if self.verify_frames in (1, 3):
                    self.save(image, f'after_click_{self.verify_frames}')
            self.job = runner_after(self,800, self.tick)
        except Exception as exc:
            self.finish(str(exc), image)
