"""Observe only an exposed HUD; request foreground work on a proven return."""
from PIL import Image
from stall_watch import note_frame
from observation_menu import observe_menu
from game_actions import check_observation_area
from window_link import capture
from vision import from_capture,special_hud_timer,town,general_location,special_screen,special_icon


def observe_return(runner):
    runner.passive_visible=False
    try:
        before=check_observation_area(runner.handle)
        source=from_capture(capture(runner.handle))
        if check_observation_area(runner.handle)!=before:return False
    except RuntimeError:
        runner.passive_return_hits=0
        return False
    # Do not interpret any pixels outside the independently visible HUD.
    image=Image.new('RGB',(800,600))
    image.paste(source.crop((580,0,800,150)),(580,0))
    if observe_menu(runner,image):return True
    if special_screen(image)>=.70 or special_icon(image)[0]>=.82:return False
    timer=special_hud_timer(image)
    if timer>=.78:
        note_frame(runner.owner,image,scope='hud',hunting=True)
        runner.passive_seen_timer=True
        runner.passive_return_hits=0
        runner.passive_visible=True
        return True
    returned=(timer<.60 and (getattr(runner,'passive_seen_timer',False) or getattr(runner,'hunt_confirmed',False)) and
              max(town(image),general_location(image,runner.owner.general_key))>=.85)
    runner.passive_return_hits=getattr(runner,'passive_return_hits',0)+1 if returned else 0
    if returned:
        note_frame(runner.owner,image,scope='hud',hunting=False)
        runner.passive_visible=True
        if runner.passive_return_hits>=3:
            runner.log('창 전환 없이 시간표시 소멸·복귀 지역 3회 확인 → 즉시 다음 작업')
            runner.passive_return_hits=0
            runner.inspect()
        return True
    return False


def event_return_visible(runner):
    """An exposed own-field name proves natural event return; no focus/input."""
    try:
        before=check_observation_area(runner.handle)
        source=from_capture(capture(runner.handle))
        if check_observation_area(runner.handle)!=before:return False
    except RuntimeError:
        runner.passive_event_hits=0
        return False
    image=Image.new('RGB',(800,600))
    image.paste(source.crop((580,0,800,150)),(580,0))
    if observe_menu(runner,image):return False
    valid=(special_screen(image)<.70 and special_icon(image)[0]<.82 and
           general_location(image,runner.owner.general_key)>=.85)
    runner.passive_event_hits=getattr(runner,'passive_event_hits',0)+1 if valid else 0
    if valid:note_frame(runner.owner,image,scope='hud',hunting=False)
    return runner.passive_event_hits>=3
